package com.mdm.api.common;

import io.restassured.response.Response;
import lombok.Getter;
import lombok.Setter;

public class GenericDTO<C> {

	@Getter @Setter
	C response;

	public void toClass(Response response, Class<C> class1) {
		try {
			if (null !=response.jsonPath().get("error")) {

			} else {
				this.response = response.as(class1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}




}
