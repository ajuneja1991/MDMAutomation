package com.mdm.api.requests;

public class CreateProjectRequest {

}
