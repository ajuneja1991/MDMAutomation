package com.mdm.api.common;

public class EndPoints {
	private EndPoints() {}

	public static class CreateProject{
		private CreateProject() {}
		
		public static final String MDM_GET_CUSTOMERDETAILS = "/ebx-dataservices/rest/data/v1/Btransdataspace/transdataset/root/customers";
	}
}
