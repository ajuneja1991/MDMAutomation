package com.mdm.api.response;

public class CreateProjectResponse {

}
