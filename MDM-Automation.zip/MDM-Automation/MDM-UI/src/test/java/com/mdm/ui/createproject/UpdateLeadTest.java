package com.mdm.ui.createproject;

import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.mdm.array.PrettyPrintArray;
import com.mdm.configuration.ConfigurationManager;
import com.mdm.ui.common.BaseTest;
import com.mdm.ui.constants.TestConstants;
import com.mdm.ui.dataprovider.CreateLeadDataProvider;
import com.mdm.ui.pages.CreateLeadPage;
import com.mdm.ui.pages.FeesPage;
import com.mdm.ui.pages.LeadOutcomesPage;
import com.mdm.ui.pages.LegalEntitiesPage;
import com.mdm.ui.pages.LinkedDocumentsPage;
import com.mdm.ui.pages.MDMHomePage;
import com.mdm.ui.pages.MainTabPage;
import com.mdm.ui.pages.ProjectClientTeamDetailsPage;
import com.mdm.ui.pages.TeamPage;
import com.mdm.ui.utils.ReadGridData;
import com.mdm.validation.Validator;

public class UpdateLeadTest extends BaseTest {

	CreateLeadPage createProject;
	TeamPage team_Tab;
	ProjectClientTeamDetailsPage projectClientTeamDetails_Tab;
	FeesPage fees_Tab;
	LegalEntitiesPage legalEntities_Tab;
	LeadOutcomesPage leadOutcomes_Tab;
	LinkedDocumentsPage linkedDocuments_Tab;
	MDMHomePage dashboard;
	MainTabPage mainTab;
	private Map<String, String> createdLeadData;
	private Map<String, String> updateLeadData;
	
	@BeforeClass
	public void before() throws Exception {
		createProject = CreateLeadPage.getCreateProjectObject(getDriver());
		team_Tab = TeamPage.getTeamPageObject(getDriver());
		projectClientTeamDetails_Tab = ProjectClientTeamDetailsPage.getProjectClientTeamDetailsPageObject(getDriver());
		fees_Tab = FeesPage.getFeesPageObject(getDriver());
		legalEntities_Tab = LegalEntitiesPage.getLegalEntitiesPageObject(getDriver());
		leadOutcomes_Tab = LeadOutcomesPage.getLeadOutcomesPageObject(getDriver());
		linkedDocuments_Tab = LinkedDocumentsPage.getLinkedDocumentsPageObject(getDriver());
		dashboard = MDMHomePage.getMDMHomePageObject(getDriver());
		mainTab = MainTabPage.getMainTabObject(getDriver());
	}

	@Test(priority = 1, dataProvider = "createNewLead", dataProviderClass = CreateLeadDataProvider.class)
	public void createLead(Map<String,Object> data) throws Exception {		
		createProject.navigateToLeadCreation(data.get("Client Company").toString());
		Map<String, String> inputData=createProject.setProjectsValue(data);
		createdLeadData = createProject.getProjectsValue();
		Validator.log(" ----- User validate that the lead data is displayed correctly. ----- ");
		Validator.verifySubSet(createdLeadData,inputData, "All the value that we set should be displayed along with Project ID",new String[]{"Data in Create Page","Data on Main Tab"});

	}
	
	@Test(priority = 2, dataProvider = "updateLead", dataProviderClass = CreateLeadDataProvider.class)
	public void validateUpdateLead(Map<String,Object> data) throws Exception {
		createProject.goToURL(ConfigurationManager.getInstance().getProperty("ui.dev.url"));
		//28382
		dashboard.navigateToProject(createdLeadData.get("Projects ID"),"Projects",TestConstants.UserRole.DS);//"28,382");
		
		String[] fieldsToUpdate = {"Type","Division","Project/Position","Local Language Position","Position Based", 
				"Practice Group 1","Practice Sub Group 1","Practice Group 2","Practice Subgroup 2","Function","PC/SWF","Family Business","Executing Office","Originating Office",
				"Venture Engine","Confidential","VAT Number"};
		Map<String, String> updatedData=mainTab.updateProjectsValue(fieldsToUpdate,data);
		updateLeadData = mainTab.getDataOnMainTab();
		Validator.log(" ----- User validate that the updated data is displayed correctly. ----- ");
		Validator.verifySubSet(updateLeadData,updatedData, "All the value that we updated should be displayed in Main Tab",new String[]{"Main Tab Data","Updated Data on Main Tab"});

	}
	
	@Test(priority = 3)
	public void validateLeadInOrchestra() throws Exception {

		Validator.log(" ------ User validate the lead data in Orchestra. ------ ");
		Map<String, String> updateLeadDataOrchestra=createProject.getLeadDataOrchestra(updateLeadData.get("Projects ID"));
		
		Validator.log("Create Lead data in Orchestra", updateLeadDataOrchestra);		
		Validator.verifyMap(updateLeadData,updateLeadDataOrchestra, "All the values for Lead should be updated in Orchestra");
		
	}
	
	
	@Test(priority = 4)
	public void validateTab_Team() throws Exception {
		
		Validator.log(" ------ User validate the Team tab after Update Lead  ------ ");
		createProject.selectTab("Team");
		
		Validator.log(" ------ User validate the Team Grid Data. ------ ");
		Object[][] teamGridDataOrchestra= team_Tab.getTeamGridDataOrchestra(updateLeadData.get("Projects ID"));
				
		Validator.log("Team Tab Grid data in Orchestra", PrettyPrintArray.print(teamGridDataOrchestra));
		
		String[][] teamGridData= ReadGridData.getInstance(getDriver()).getGridValue();
		Validator.verifyArray(teamGridData,teamGridDataOrchestra, "All the values displayed in Team Tab Grid in MDM should be updated in Orchestra");
		
	}
	
	@Test(priority = 5)
	public void validateTab_ProjectClientTeamDetails() throws Exception {
		
		Validator.log(" ------ User validate the Project Client Team Details tab after Update Lead  ------ ");
		createProject.selectTab("Project Client Team Details");
		projectClientTeamDetails_Tab.validateProjectClientTeamDetailsGrid();
		
	}
	
	@Test(priority = 6)
	public void validateTab_Fees() throws Exception {
		Validator.log(" ------ User validate the Fees tab after Update Lead  ------ ");
		createProject.selectTab("Fees");
		
		Validator.log(" ------ User validate the Fees Grid Data. ------ ");
		Object[][] feesGridDataOrchestra= fees_Tab.getFeesGridDataOrchestra(updateLeadData.get("Orchestra Quick Number"));
				
		Validator.log("Fees Grid data in Orchestra", PrettyPrintArray.print(feesGridDataOrchestra));
		
		String[][] feesGridData= ReadGridData.getInstance(getDriver()).getGridValue();
		Validator.verifyArray(feesGridData,feesGridDataOrchestra, "All the values displayed in Fee Grid in MDM should be updated in Orchestra");
		
		
	}
	
	@Test(priority = 7)
	public void validateTab_LegalEntities() throws Exception {
		Validator.log(" ------ User validate the Legal Entities tab after Update Lead  ------ ");
		createProject.selectTab("Legal Entities");
		legalEntities_Tab.validateLegalEntitiesGrid();
	}
	
	@Test(priority = 8)
	public void validateTab_LeadOutcomes() throws Exception {
		Validator.log(" ------ User validate the Lead Outcomes tab after Update Lead  ------ ");
		createProject.selectTab("Lead Outcomes");
		leadOutcomes_Tab.validateLeadOutcomesGrid(updateLeadData.get("Projects ID"));
	}
	
	@Test(priority = 9)
	public void validateTab_LinkedDocuments() throws Exception {
		Validator.log(" ------ User validate the Linked Documents tab after Update Lead ------ ");
		createProject.selectTab("Linked Documents");
		linkedDocuments_Tab.validateLinkedDocumentsGrid();
	}
	
	
}
