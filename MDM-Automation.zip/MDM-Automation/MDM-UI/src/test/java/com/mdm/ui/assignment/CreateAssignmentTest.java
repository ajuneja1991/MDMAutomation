package com.mdm.ui.assignment;

import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.mdm.array.PrettyPrintArray;
import com.mdm.ui.common.BaseTest;
import com.mdm.ui.constants.TestConstants;
import com.mdm.ui.dataprovider.CreateLeadDataProvider;
import com.mdm.ui.pages.CreateAssignmentPage;
import com.mdm.ui.pages.CreateLeadPage;
import com.mdm.ui.pages.FeesPage;
import com.mdm.ui.pages.LeadOutcomesPage;
import com.mdm.ui.pages.LegalEntitiesPage;
import com.mdm.ui.pages.LinkedDocumentsPage;
import com.mdm.ui.pages.MDMHomePage;
import com.mdm.ui.pages.ProjectClientTeamDetailsPage;
import com.mdm.ui.pages.TeamPage;
import com.mdm.ui.utils.ReadGridData;
import com.mdm.validation.Validator;

public class CreateAssignmentTest extends BaseTest {

	CreateLeadPage createProject;
	CreateAssignmentPage createAssignment;
	TeamPage team_Tab;
	ProjectClientTeamDetailsPage projectClientTeamDetails_Tab;
	FeesPage fees_Tab;
	LegalEntitiesPage legalEntities_Tab;
	LeadOutcomesPage leadOutcomes_Tab;
	LinkedDocumentsPage linkedDocuments_Tab;
	MDMHomePage dashboard;
	private Map<String, String> createdLeadData,createAssignmentData;
	
	@BeforeClass
	public void before() throws Exception {
		createProject = CreateLeadPage.getCreateProjectObject(getDriver());
		createAssignment = CreateAssignmentPage.getCreateAssignmentPageObject(getDriver());
		team_Tab = TeamPage.getTeamPageObject(getDriver());
		projectClientTeamDetails_Tab = ProjectClientTeamDetailsPage.getProjectClientTeamDetailsPageObject(getDriver());
		fees_Tab = FeesPage.getFeesPageObject(getDriver());
		legalEntities_Tab = LegalEntitiesPage.getLegalEntitiesPageObject(getDriver());
		leadOutcomes_Tab = LeadOutcomesPage.getLeadOutcomesPageObject(getDriver());
		linkedDocuments_Tab = LinkedDocumentsPage.getLinkedDocumentsPageObject(getDriver());
		dashboard = MDMHomePage.getMDMHomePageObject(getDriver());
	}
	
	@Test(priority = 1, dataProvider = "createNewLead", dataProviderClass = CreateLeadDataProvider.class)
	public void createLead(Map<String,Object> data) throws Exception {		
		createProject.navigateToLeadCreation(data.get("Client Company").toString());
		Map<String, String> inputData=createProject.setProjectsValue(data);
		createdLeadData = createProject.getProjectsValue();
		Validator.log(" ----- User validate that the lead data is displayed correctly. ----- ");
		Validator.verifySubSet(createdLeadData,inputData, "All the value that we set should be displayed along with Project ID",new String[]{"Data in Create Page","Data on Main Tab"});

	}
	
	@Test(priority = 2)
	public void validateCreateAssignment() throws Exception {
		
		createAssignmentData = createAssignment.createAssignment(createdLeadData.get("Projects ID"));
		
		Validator.log(" ------ User validate Create Assignment data in Orchestra. ------ ");
		Map<String,String> orchestraData = createAssignment.getAssignmentDataOrchestra(createAssignmentData.get("Projects ID"));
		Validator.log("Create Assignment data in Orchestra", orchestraData);		
		Validator.verifyMap(createAssignmentData,orchestraData, "All the values for Assignment should be updated in Orchestra");
		
	}
		
	@Test(priority = 3)
	public void validateTab_Team_NewAssignment() throws Exception {
		
		Validator.log(" ------ User validate the Team tab after New Assignment Creation. ------ ");
		createProject.selectTab("Team");
		
		Validator.log(" ------ User validate the Team Grid Data. ------ ");
		Object[][] teamGridDataOrchestra= team_Tab.getTeamGridDataOrchestra(createAssignmentData.get("Projects ID"));
				
		Validator.log("Team Tab Grid data in Orchestra", PrettyPrintArray.print(teamGridDataOrchestra));
		
		String[][] teamGridData= ReadGridData.getInstance(getDriver()).getGridValue();
		Validator.verifyArray(teamGridData,teamGridDataOrchestra, "All the values displayed in Team Tab Grid in MDM should be updated in Orchestra");
		
	}
	
	@Test(priority = 4)
	public void validateTab_ProjectClientTeamDetails_NewAssignment() throws Exception {
		
		Validator.log(" ------ User validate the Project Client Team Details tab after New Assignment Creation. ------ ");
		createProject.selectTab("Project Client Team Details");
		projectClientTeamDetails_Tab.validateProjectClientTeamDetailsGrid();
		
	}
	
	@Test(priority = 5)
	public void validateTab_Fees_NewAssignment() throws Exception {
		Validator.log(" ------ User validate the Fees tab after New Assignment Creation. ------ ");
		createProject.selectTab("Fees");
		
		Validator.log(" ------ User validate the Fees Grid Data. ------ ");
		Object[][] feesGridDataOrchestra= fees_Tab.getFeesGridDataOrchestra(createAssignmentData.get("Orchestra Quick Number"));
				
		Validator.log("Fees Grid data in Orchestra", PrettyPrintArray.print(feesGridDataOrchestra));
		
		String[][] feesGridData= ReadGridData.getInstance(getDriver()).getGridValue();
		Validator.verifyArray(feesGridData,feesGridDataOrchestra, "All the values displayed in Fee Grid in MDM should be updated in Orchestra");
		
		
	}
	
	@Test(priority = 6)
	public void validateTab_LegalEntities_NewAssignment() throws Exception {
		Validator.log(" ------ User validate the Legal Entities tab after New Assignment Creation. ------ ");
		createProject.selectTab("Legal Entities");
		legalEntities_Tab.validateLegalEntitiesGrid();
	}
	
	
	@Test(priority = 7)
	public void validateTab_LinkedDocuments_NewAssignment() throws Exception {
		Validator.log(" ------ User validate the Linked Documents tab after New Assignment Creation. ------ ");
		createProject.selectTab("Linked Documents");
		linkedDocuments_Tab.validateLinkedDocumentsGrid();
	}
	
	
	@Test(priority = 8)
	public void validateTab_LeadOutcomes_NewAssignment() throws Exception {
		Validator.log(" ------ User validate the Lead Outcomes tab after New Assignment Creation. ------ ");
		String projectsId=createAssignmentData.get("Originating Lead ID");
		dashboard.navigateToProject(projectsId,"Projects",TestConstants.UserRole.DS);
		createProject.selectTab("Lead Outcomes");
		leadOutcomes_Tab.validateLeadOutcomesGrid(projectsId);
	}
}
