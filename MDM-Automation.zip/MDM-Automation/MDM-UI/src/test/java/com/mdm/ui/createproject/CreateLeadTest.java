package com.mdm.ui.createproject;

import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.mdm.array.PrettyPrintArray;
import com.mdm.ui.common.BaseTest;
import com.mdm.ui.dataprovider.CreateLeadDataProvider;
import com.mdm.ui.pages.CreateLeadPage;
import com.mdm.ui.pages.FeesPage;
import com.mdm.ui.pages.LeadOutcomesPage;
import com.mdm.ui.pages.LegalEntitiesPage;
import com.mdm.ui.pages.LinkedDocumentsPage;
import com.mdm.ui.pages.ProjectClientTeamDetailsPage;
import com.mdm.ui.pages.TeamPage;
import com.mdm.ui.utils.ReadGridData;
import com.mdm.validation.Validator;

public class CreateLeadTest extends BaseTest {

	CreateLeadPage createProject;
	TeamPage team_Tab;
	ProjectClientTeamDetailsPage projectClientTeamDetails_Tab;
	FeesPage fees_Tab;
	LegalEntitiesPage legalEntities_Tab;
	LeadOutcomesPage leadOutcomes_Tab;
	LinkedDocumentsPage linkedDocuments_Tab;
	private Map<String, String> createdLeadData;
	
	@BeforeClass
	public void before() throws Exception {
		createProject = CreateLeadPage.getCreateProjectObject(getDriver());
		team_Tab = TeamPage.getTeamPageObject(getDriver());
		projectClientTeamDetails_Tab = ProjectClientTeamDetailsPage.getProjectClientTeamDetailsPageObject(getDriver());
		fees_Tab = FeesPage.getFeesPageObject(getDriver());
		legalEntities_Tab = LegalEntitiesPage.getLegalEntitiesPageObject(getDriver());
		leadOutcomes_Tab = LeadOutcomesPage.getLeadOutcomesPageObject(getDriver());
		linkedDocuments_Tab = LinkedDocumentsPage.getLinkedDocumentsPageObject(getDriver());
		createProject.navigateToLeadCreation();
	}

	@Test(priority = 1)
	public void verifyProjectIdAtLaunch() throws InterruptedException {	
		Validator.verifyResult(createProject.getFieldValue("Projects ID"), "[ auto-incremented value ]", "User should see expected value in the field.");
	}

	@Test(priority = 2, dataProvider = "createNewLead", dataProviderClass = CreateLeadDataProvider.class)
	public void verifyProjectDescription(Map<String,Object> expectedData) {
		Validator.verifyResult(createProject.getFieldValue("Projects Description"), expectedData.get("Projects Description"));
	}

	@Test(priority = 3, dataProvider = "createNewLead", dataProviderClass = CreateLeadDataProvider.class)
	public void verifyClientCompany(Map<String,Object> data) throws Exception {		
		Validator.verifyResult(createProject.getFieldValue("Client Company"),data.get("Client Company").toString(),"Correct Client Company should be displayed as in the DB for the specified Company ID");
	}

	@Test(priority = 4, dataProvider = "createNewLead", dataProviderClass = CreateLeadDataProvider.class)
	public void verifyPcSwf(Map<String,Object> data) throws Exception {
		Validator.verifyResult(createProject.getValueInDropdown("PC/SWF"),createProject.getpcSwfDB(data.get("Client Company").toString()),"Correct PC/SWF should be displayed as in the DB for the specified Company ID");
	}

	@Test(priority = 5, dataProvider = "createNewLead", dataProviderClass = CreateLeadDataProvider.class)
	public void validateCreateLead(Map<String,Object> data) throws Exception {	
		
		Validator.log("####### TEST DATA SCENARIO "+ data.get("Scenario").toString());
		createProject.navigateToLeadCreation(data.get("Client Company").toString());
		Map<String, String> inputData=createProject.setProjectsValue(data);
		createdLeadData = createProject.getProjectsValue();
		Validator.log(" ----- User validate that the lead data is displayed correctly. ----- ");
		Validator.verifySubSet(createdLeadData,inputData, "All the value that we set should be displayed along with Project ID",new String[]{"Data in Create Page","Data on Main Tab"});
	}

	@Test(priority = 6)//, dependsOnMethods = "validateCreateLead")
	public void validateLeadInOrchestra() throws Exception {

		Validator.log(" ------ User validate the lead data in Orchestra. ------ ");
		Map<String, String> createLeadDataOrchestra=createProject.getLeadDataOrchestra(createdLeadData.get("Projects ID"));
		
		Validator.log("Create Lead data in Orchestra", createLeadDataOrchestra);		
		Validator.verifyMap(createdLeadData,createLeadDataOrchestra, "All the values for Lead should be updated in Orchestra");
		
	}
	
	
	@Test(priority = 7)//, dependsOnMethods = "validateCreateLead")
	public void validateTab_Team() throws Exception {
		
		Validator.log(" ------ User validate the Team tab after New Lead Creation. ------ ");
		createProject.selectTab("Team");
		
		Validator.log(" ------ User validate the Team Grid Data. ------ ");
		Object[][] teamGridDataOrchestra= team_Tab.getTeamGridDataOrchestra(createdLeadData.get("Projects ID"));
				
		Validator.log("Team Tab Grid data in Orchestra", PrettyPrintArray.print(teamGridDataOrchestra));
		
		String[][] teamGridData= ReadGridData.getInstance(getDriver()).getGridValue();
		Validator.verifyArray(teamGridData,teamGridDataOrchestra, "All the values displayed in Team Tab Grid in MDM should be updated in Orchestra");
		
	}
	
	@Test(priority = 8)//, dependsOnMethods = "validateCreateLead")
	public void validateTab_ProjectClientTeamDetails() throws Exception {
		
		Validator.log(" ------ User validate the Project Client Team Details tab after New Lead Creation. ------ ");
		createProject.selectTab("Project Client Team Details");
		projectClientTeamDetails_Tab.validateProjectClientTeamDetailsGrid();
		
	}
	
	@Test(priority = 9)//, dependsOnMethods = "validateCreateLead")
	public void validateTab_Fees() throws Exception {
		fees_Tab.validateFeesGridData(createdLeadData.get("Orchestra Quick Number"));
	}
	
	@Test(priority = 10)//, dependsOnMethods = "validateCreateLead")
	public void validateTab_LegalEntities() throws Exception {
		Validator.log(" ------ User validate the Legal Entities tab after New Lead Creation. ------ ");
		createProject.selectTab("Legal Entities");
		legalEntities_Tab.validateLegalEntitiesGrid();
	}
	
	@Test(priority = 11)//, dependsOnMethods = "validateCreateLead")
	public void validateTab_LeadOutcomes() throws Exception {
		Validator.log(" ------ User validate the Lead Outcomes tab after New Lead Creation. ------ ");
		createProject.selectTab("Lead Outcomes");
		leadOutcomes_Tab.validateLeadOutcomesGrid(createdLeadData.get("Projects ID"));
	}
	
	@Test(priority = 12)//, dependsOnMethods = "validateCreateLead")
	public void validateTab_LinkedDocuments() throws Exception {
		Validator.log(" ------ User validate the Linked Documents tab after New Lead Creation. ------ ");
		createProject.selectTab("Linked Documents");
		linkedDocuments_Tab.validateLinkedDocumentsGrid();
	}
	
	
	@Test(enabled = false,groups= {"Smoke"},dataProvider = "createLead_Regression", dataProviderClass = CreateLeadDataProvider.class)
	public void validateCreateLead_Complete(Map<String,Object> data) throws Exception {	
		
		Validator.log("####### TEST DATA SCENARIO "+ data.get("Scenario").toString());
		createProject.navigateToLeadCreation(data.get("Client Company").toString());
		Map<String, String> inputData=createProject.setProjectsValue(data);
		
		boolean isMainTabDisplayed = createProject.isMainTabDisplayed();
		
		if (isMainTabDisplayed) {		
			
		createdLeadData = createProject.getProjectsValue();
		Validator.log(" ----- User validate that the lead data is displayed correctly. ----- ");
		Validator.verifySubSet(createdLeadData,inputData, "All the value that we set should be displayed along with Project ID",new String[]{"Data in Create Page","Data on Main Tab"});

		/////////////////////////
		
		Validator.log(" ------ User validate the lead data in Orchestra. ------ ");
		Map<String, String> createLeadDataOrchestra=createProject.getLeadDataOrchestra(createdLeadData.get("Projects ID"));
		
		Validator.log("Create Lead data in Orchestra", createLeadDataOrchestra);		
		Validator.verifyMap(createdLeadData,createLeadDataOrchestra, "All the values for Lead should be updated in Orchestra");
		
		} else { 
			createProject.validateError(data.get("Expected Error").toString());
		}
		
	}

}
