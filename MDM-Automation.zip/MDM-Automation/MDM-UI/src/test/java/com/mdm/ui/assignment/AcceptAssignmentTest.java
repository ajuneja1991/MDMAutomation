package com.mdm.ui.assignment;

import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.mdm.ui.common.BaseTest;
import com.mdm.ui.dataprovider.CreateLeadDataProvider;
import com.mdm.ui.pages.CreateAssignmentPage;
import com.mdm.ui.pages.CreateLeadPage;
import com.mdm.ui.pages.MDMHomePage;
import com.mdm.ui.pages.MainTabPage;
import com.mdm.ui.pages.TransactionalDatasetPage;
import com.mdm.validation.Validator;

public class AcceptAssignmentTest extends BaseTest {
	
	CreateLeadPage createProject;
	CreateAssignmentPage createAssignment;
	MainTabPage main_Tab;
	TransactionalDatasetPage transactionalDatasetPage;
	MDMHomePage dashboard;
	private Map<String, String> createdLeadData,createAssignmentData;
	@BeforeClass
	public void before() throws Exception {
		createProject = CreateLeadPage.getCreateProjectObject(getDriver());
		createAssignment = CreateAssignmentPage.getCreateAssignmentPageObject(getDriver());
		main_Tab = MainTabPage.getMainTabObject(getDriver());
		transactionalDatasetPage = TransactionalDatasetPage.getTransactionalDatasetPageObject(getDriver());
		dashboard = MDMHomePage.getMDMHomePageObject(getDriver());
	}
	
	@Test(priority = 1, dataProvider = "createNewLead", dataProviderClass = CreateLeadDataProvider.class)
	public void createLead(Map<String,Object> data) throws Exception {		
		createProject.navigateToLeadCreation(data.get("Client Company").toString());
		Map<String, String> inputData=createProject.setProjectsValue(data);
		createdLeadData = createProject.getProjectsValue();
		Validator.log(" ----- User validate that the lead data is displayed correctly. ----- ");
		Validator.verifySubSet(createdLeadData,inputData, "All the value that we set should be displayed along with Project ID",new String[]{"Data in Create Page","Data on Main Tab"});

	}
	
	@Test(priority = 2)
	public void validateCreateAssignment() throws Exception {
		
		createAssignmentData = createAssignment.createAssignment(createdLeadData.get("Projects ID"));
		
		Validator.log(" ------ User validate Create Assignment data in Orchestra. ------ ");
		Map<String,String> orchestraData = createAssignment.getAssignmentDataOrchestra(createAssignmentData.get("Projects ID"));
		Validator.log("Create Assignment data in Orchestra", orchestraData);		
		Validator.verifyMap(createAssignmentData,orchestraData, "All the values for Assignment should be updated in Orchestra");
		
	}
	
	@Test(priority = 3, dataProvider = "editAssignment", dataProviderClass = CreateLeadDataProvider.class)
	public void validatePGConfirmation(Map<String,Object> data) throws Exception {		
		main_Tab.validatePGConfirmationRejection(createAssignmentData.get("Projects ID"), createAssignmentData.get("Orchestra Quick Number"), data, true);
	}
	
	@Test(priority = 4)
	public void validatePGDashboardAfterConfirmation() throws Exception {		
		dashboard.validateGridAfterDSReview(createAssignmentData.get("Projects ID"));
	}

}
