package com.mdm.ui.createproject;

import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.mdm.ui.common.BaseTest;
import com.mdm.ui.dataprovider.DuplicateLeadDataProvider;
import com.mdm.ui.pages.CreateLeadPage;
import com.mdm.ui.pages.MainTabPage;
import com.mdm.validation.Validator;

public class DuplicateLeadTest extends BaseTest {

	CreateLeadPage createProject;
	MainTabPage mainTabPage;
	private Map<String, String> createdLeadData;
	
	@BeforeClass
	public void before() throws Exception {
		createProject = CreateLeadPage.getCreateProjectObject(getDriver());
		mainTabPage = MainTabPage.getMainTabObject(getDriver());
	}

	@Test(priority = 1, dataProvider = "createNewLead", dataProviderClass = DuplicateLeadDataProvider.class)
	public void validateCreateLead(Map<String,Object> data) throws Exception {	
		
		Validator.log("####### TEST DATA SCENARIO "+ data.get("Scenario").toString());
		createProject.navigateToLeadCreation(data.get("Client Company").toString());
		Map<String, String> inputData=createProject.setProjectsValue(data);
		createdLeadData = createProject.getProjectsValue();
		Validator.log(" ----- User validate that the lead data is displayed correctly. ----- ");
		Validator.verifySubSet(createdLeadData,inputData, "All the value that we set should be displayed along with Project ID",new String[]{"Data in Create Page","Data on Main Tab"});
	}
	
	
	@Test(priority = 2, dataProvider = "duplicateLeadData", dataProviderClass = DuplicateLeadDataProvider.class)
	public void validateDuplicateLeadCreation(Map<String, Object> data) throws Exception {
		Validator.log("####### TEST DATA SCENARIO => "+ data.get("Scenario").toString()+ " #######");
		createProject.goToURL(createProject.getCreateLeadPageURL(data.get("Client Company").toString()));
		Map<String, String> inputData=createProject.setProjectsValue(data);
		
		if (data.get("Should Create?").toString().equalsIgnoreCase("Yes")) {
			createdLeadData = createProject.getProjectsValue();
			Validator.log(" ----- User validate that the lead data is displayed correctly. ----- ");
			Validator.verifySubSet(createdLeadData,inputData, "All the value that we set should be displayed along with Project ID",new String[]{"Data in Create Page","Data on Main Tab"});
		}else {
			mainTabPage.validateErrorPopup(createdLeadData.get("Projects ID"));
		}
			
	}
	
	}
