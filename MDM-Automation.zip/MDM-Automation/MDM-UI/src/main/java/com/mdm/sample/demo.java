package com.mdm.sample;

import java.io.IOException;

import com.mdm.configuration.ConfigurationManager;

public class demo {
	
	public static void main(String[] args) throws IOException {
		ConfigurationManager.configFileName="config.properties";
		String a = ConfigurationManager.getInstance().getProperty("value");
	System.out.println(a);
	}

}
