package com.mdm.ui.constants;

public class ErrorMessages{

	private ErrorMessages() {
		throw new IllegalStateException("Can not create object of Error Messages class");
	}

	public static final String DUPLICATE_LEAD="The requested operation has failed. Reason: This lead seems to be a duplicate and therefore cannot be created. Please check the existing lead record (MDM Project ID: {0}) in Orchestra created in the last hour for this Type, Client Company, Position and Lead Consultant.";
	
	public  static final String[] CONFIRMASSIGNMENT_ERROR= new String[] {"Assignment Confirmed: Please enter Invoice Office.",
				"Assignment Confirmed: Please enter Office Split.",
				"Assignment Confirmed: Please enter Legal Entities details.",
				"Assignment Confirmed: Please enter an Invoice Language."};

			
}
