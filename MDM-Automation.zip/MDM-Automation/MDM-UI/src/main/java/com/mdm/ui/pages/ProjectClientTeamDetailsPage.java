package com.mdm.ui.pages;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.WebDriver;

import com.mdm.ui.common.BasePage;
import com.mdm.ui.constants.TestConstants;
import com.mdm.ui.utils.ReadGridData;
import com.mdm.validation.Validator;

public class ProjectClientTeamDetailsPage extends BasePage  {

	private static ProjectClientTeamDetailsPage projectClientTeamDetailsPage = null;
	public ProjectClientTeamDetailsPage(WebDriver driver) {
		super(driver);
		this.driver=driver;
	}

	public synchronized static ProjectClientTeamDetailsPage getProjectClientTeamDetailsPageObject(WebDriver driver){
		if (projectClientTeamDetailsPage == null) {
			projectClientTeamDetailsPage = new ProjectClientTeamDetailsPage(driver);
		}
		return projectClientTeamDetailsPage;
	}
	
	public void validateProjectClientTeamDetailsGrid() {
		Validator.log("-------- User Validate the default columns on the screen -------");
		System.out.println();
		List<String> actualHeader = ReadGridData.getInstance(driver).getHeader();
		List<String> expectedHeader =Arrays.asList( TestConstants.getProjectClientTeamDetailsGridHeader);
		Validator.verifyResult(actualHeader, expectedHeader, "All the expected columns should be displayed on Project Client Team Details Tab grid for New Lead Created.");
	
		Validator.log("-------- User Validate the data displayed in the grid -------");
		Validator.verifyResult(ReadGridData.getInstance(driver).isGridEmpty(), true, " No Records found. should be displayed in the Grid");
	}
	
}
