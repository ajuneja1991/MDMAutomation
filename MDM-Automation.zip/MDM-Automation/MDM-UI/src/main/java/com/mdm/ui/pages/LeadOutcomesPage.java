package com.mdm.ui.pages;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.WebDriver;

import com.mdm.array.PrettyPrintArray;
import com.mdm.database.DatabaseUtil;
import com.mdm.ui.common.BasePage;
import com.mdm.ui.constants.TestConstants;
import com.mdm.ui.constants.SQLQueries;
import com.mdm.ui.utils.ReadGridData;
import com.mdm.validation.Validator;

public class LeadOutcomesPage extends BasePage  {

	private static LeadOutcomesPage leadOutcomesPage;
	public LeadOutcomesPage(WebDriver driver) {
		super(driver);
		this.driver=driver;
	}

	public synchronized static LeadOutcomesPage getLeadOutcomesPageObject(WebDriver driver) {
		if (leadOutcomesPage == null) {
			leadOutcomesPage = new LeadOutcomesPage(driver);
		}
		return leadOutcomesPage;
	}

	public Object[][] getLeadOutcomesGridDataOrchestra(String projectId) {
		String id=projectId.replaceAll("[^0-9]", "");
		String query = SQLQueries.getLeadOutcomesGrid_Orchestra_Query+id;
		return DatabaseUtil.dbContext().getDataWithColumn(query);
	}

	public void validateLeadOutcomesGrid(String projectId) {
		Validator.log("-------- User Validate the default columns on the screen -------");

		Object [][] leadOutcomeGridDataOrchestra = getLeadOutcomesGridDataOrchestra(projectId);

		if(leadOutcomeGridDataOrchestra.length == 0) 
		{	
			List<String> actualHeader = ReadGridData.getInstance(driver).getHeader();
			List<String> expectedHeader =Arrays.asList( TestConstants.getLeadOutcomesGridHeader);
			Validator.verifyResult(actualHeader, expectedHeader, "All the expected columns should be displayed on Lead Outcomes Tab grid for New Lead Created.");

			Validator.log("-------- User Validate the data displayed in the grid -------");
			Validator.verifyResult(ReadGridData.getInstance(driver).isGridEmpty(), true, " No Records found. should be displayed in the Grid");	
		}
		else 
		{
			Validator.log("Lead Outcome Grid data in Orchestra", PrettyPrintArray.print(leadOutcomeGridDataOrchestra));			
			String[][] leadOutcomeGridData= ReadGridData.getInstance(driver).getGridValue();
			Validator.verifyArray(leadOutcomeGridData,leadOutcomeGridDataOrchestra, "All the values displayed in Lead Outcome Grid in MDM should be updated in Orchestra");

		}
	}
}
