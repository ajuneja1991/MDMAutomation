package com.mdm.ui.dataprovider;

import java.util.Map;

import org.testng.annotations.DataProvider;

import com.codoid.products.exception.FilloException;
import com.mdm.excel.ExcelUtil;
import com.mdm.string.RandomStringGenerator;

public class CreateLeadDataProvider {

	@DataProvider (name = "createNewLead")
	public Object[][] createNewLead() throws FilloException{
		Object[][] data= new ExcelUtil().readExcelData("Select * from CreateLead");
		String randamString= RandomStringGenerator.get(6);
		
		for (Object[] objects : data) {
			@SuppressWarnings("unchecked")
			Map<String, Object> map = (Map<String, Object>) objects[0];
			for (String key : map.keySet()) {
				if(key.equalsIgnoreCase("Project/Position")) {
					map.put(key, map.get(key) + "_"+randamString);
					break;
				}
			}
		}
		
		return data;
	} 

	@DataProvider (name = "createLead_Regression")
	public Object[][] createLead() throws FilloException{
		return new ExcelUtil().readExcelData("Select * from CreateLead_TestData");
	} 

	@DataProvider (name = "updateLead")
	public Object[][] updateLead() throws FilloException{
		return new ExcelUtil().readExcelData("Select * from UpdateLead");
	} 

	@DataProvider (name = "updateAssignment")
	public Object[][] updateAssignment() throws FilloException{
		return new ExcelUtil().readExcelData("Select * from UpdateAssignment");
	}

	@DataProvider (name = "editAssignment")
	public Object[][] editAssignment() throws FilloException{
		return new ExcelUtil().readExcelData("Select * from EditAssignment");
	}
	
	@DataProvider (name = "confirmAssignment")
	public Object[][] confirmAssignment() throws FilloException{
		return new ExcelUtil().readExcelData("Select * from FeesTestData");
	}
	
}
