package com.mdm.ui.pages;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.mdm.array.PrettyPrintArray;
import com.mdm.database.DatabaseUtil;
import com.mdm.ui.ScreenshotUtil;
import com.mdm.ui.common.BasePage;
import com.mdm.ui.constants.SQLQueries;
import com.mdm.ui.utils.ReadGridData;
import com.mdm.validation.Validator;

public class FeesPage extends BasePage  {

	private static FeesPage feesPage;
	public FeesPage(WebDriver driver) {
		super(driver);
		this.driver=driver;
	}

	public synchronized static FeesPage getFeesPageObject(WebDriver driver){
		if (feesPage == null) {
			feesPage = new FeesPage(driver);
		}
		return feesPage;
	}
	
	public Object[][] getFeesGridDataOrchestra(String orchestraQuickNbr) {
		String id=orchestraQuickNbr.replaceAll("[^0-9]", "");
		String query = SQLQueries.getFeesTab_Orchestra_Query+id;
		return DatabaseUtil.dbContext().getDataWithColumn(query);
	}
	
	public void validateFeesGridData(String orchestraQuickNbr) {
		Validator.log(" ------ User validate the Fees tab Grid Data. ------ ");
		selectTab("Fees");
		
		Validator.log(" ------ User validate the Fees Grid Data. ------ ");
		Object[][] feesGridDataOrchestra= getFeesGridDataOrchestra(orchestraQuickNbr);
				
		Validator.log("Fees Grid data in Orchestra", PrettyPrintArray.print(feesGridDataOrchestra));
		
		String[][] feesGridData= ReadGridData.getInstance(driver).getGridValue();
		Validator.verifyArray(feesGridData,feesGridDataOrchestra, "All the values displayed in Fee Grid in MDM should be updated in Orchestra");
		
	}
	
	public void setFeesData(Map<String, Object> data) {
		try {
			selectTab("Fees");
			List<String> feesGridData= ReadGridData.getInstance(driver).getColumnValue("Fees ID");
			navigateFromGrid(feesGridData.get(0));
			switchFrameById("ebx_InternalPopup_frame");
			setFieldValue("Invoice Office", data.get("Invoice Office").toString());
			setFieldValue("Invoice Language", data.get("Invoice Language").toString());
			clickOnButton("Save");
			
			setOfficeSplit(data);
			click(driver.findElement(By.xpath("//h2[normalize-space()='Projects']/following-sibling::h2")));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void setOfficeSplit(Map<String, Object> data) throws InterruptedException, IOException {
		selectTab("Office Split");
		click(driver.findElement(By.xpath("(//button[@title='Create a record'])[2]")));
		switchFrameById("ebx_InternalPopup_frame");
		selectDropdown("Office", data.get("Office").toString());
		setValueInTextBox("Office Split %", data.get("Office Split %").toString());
		setValueInTextBox("Office Split CHF", data.get("Office Split CHF").toString());
		String screenshot = ScreenshotUtil.takeFullPageScreenshot(driver, "setProjectsValue");
		Validator.log("User update the data for lead.",data,screenshot);
		clickOnButton("Save");
		Thread.sleep(6000);
		clickOnButton("Close");
		
	}
	
	
	
	
	public static void main(String[] args) {
		String query = SQLQueries.getFeesTab_Orchestra_Query+"500027879";
		Object[][] a =DatabaseUtil.dbContext().getDataWithColumn(query);
		System.out.println(PrettyPrintArray.print(a));
	}
}
