package com.mdm.ui.pages;

import java.io.IOException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.util.Strings;

import com.mdm.configuration.ConfigurationManager;
import com.mdm.database.DatabaseUtil;
import com.mdm.datetime.DateTimeUtil;
import com.mdm.string.StringFormator;
import com.mdm.ui.ScreenshotUtil;
import com.mdm.ui.common.BasePage;
import com.mdm.ui.constants.TestConstants;
import com.mdm.ui.constants.ErrorMessages;
import com.mdm.ui.constants.SQLQueries;
import com.mdm.validation.Validator;

public class MainTabPage extends BasePage {

	private static MainTabPage pageMain = null;
	Map<String, Object> companyTableData;
	private MainTabPage(WebDriver driver) {
		super(driver);
		this.driver = driver;

	}

	public synchronized static MainTabPage getMainTabObject(WebDriver driver){
		if (pageMain == null) {
			pageMain = new MainTabPage(driver);
		}
		return pageMain;
	}
	

	private WebElement errorMsgCollapsibleBlockIdfr() {
		return driver.findElement(By.xpath("//div[@class='ebx_CollapsibleBlockContainer']/button"));
	}
	private List<WebElement> errorIdfr(){
		return driver.findElements(By.xpath("//ul[@class='ebx_Error ebx_ErrorBorder']/li"));
	}
	
	//========================================================================================

	public String getAssignmentConfirmationDateOrchestra(String orchestraQuickNbr) throws Exception {
		
		String id= StringFormator.formatNbrToString(orchestraQuickNbr);
		String query = SQLQueries.getAssignmentConfirmationDateQuery+id;
		Map<String, Object> d= DatabaseUtil.dbContext().getRecordAsMap(query).get(0);
		
		String confirmationDate = d.get("assignmentconfirmeddate").toString();
		return DateTimeUtil.getFormatedDate(confirmationDate.split(" ")[0], "yyyy-MM-dd", DateTimeUtil.DEFAULT_DATE_FORMAT);
	}
	
	public Map<String,String> updateProjectsValue(String[] updateFields,Map<String, Object> expectedData) throws InterruptedException, IOException {
	
		Map<String,String> map = new HashMap<>();

		for (String f : updateFields) {
			map.put(f, expectedData.get(f).toString().trim());
			if(Strings.isNotNullAndNotEmpty(f)) {			
				setFieldValue(f, expectedData.get(f).toString());
			}
		}

		String screenshot = ScreenshotUtil.takeFullPageScreenshot(driver, "setProjectsValue");
		Validator.log("User update the data for lead.",map,screenshot);
		clickOnButton("Save");
		Thread.sleep(10000);
		return map;
	}

	public Map<String, String> getDataOnMainTab() throws IOException{
		Map<String,String> map = new HashMap<>();
		try {
			switchFrameToSearchElement(By.xpath("//em/descendant-or-self::*[normalize-space(text())='Main']"));
			for (String name : getFieldNameList()) {			
				map.put(name, getFieldValue(name));
			}		
			String screenshot = ScreenshotUtil.takeFullPageScreenshot(driver, "getProjectsValue");
			Validator.log("User reads all the data from project-> main tab for the created lead.",map,screenshot);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return map;
	}

	public boolean isMainTabDisplayed() {
		try {
			WebElement ele = driver.findElement(By.id("ebx_WorkspaceFormTabview"));
			return ele.isDisplayed();
		} catch (Exception e) {
			return false;
		}
	}

	public void validateErrorPopup(String projectId) {
		try {
			String actualMsg = getPopupMsg();
			String expectedMsg= MessageFormat.format(ErrorMessages.DUPLICATE_LEAD,StringFormator.formatNbrToString(projectId));
			String screenshot = ScreenshotUtil.takeFullPageScreenshot(driver, "ErrorPopup");
			Validator.log("Error Pop up","Duplicate Lead",screenshot);
			Validator.verifyResult(actualMsg, expectedMsg, "Expected Message Should be same as Actual.");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public Map<String,String> editAssignment(String projectId,String[] updateFields, Map<String, Object> valuesToUpdate) throws InterruptedException, IOException {

		MDMHomePage dashboard = MDMHomePage.getMDMHomePageObject(driver);
		dashboard.navigateToProject(projectId,"Assignments",TestConstants.UserRole.PG);
		dashboard.performAction("Edit Record");
		selectTab("Main");
		Map<String,String> updatedFields = updateProjectsValue(updateFields, valuesToUpdate);

		switchFrameToSearchElement(By.xpath("//button[normalize-space()='Confirm changes']"));
		clickOnButton("Confirm changes");
		clickOnButton("OK");		
		Thread.sleep(20000);

		return updatedFields;		

	}

	public void userStartReview(String orchQuickNumber) throws InterruptedException {
		selectPersepective("Data Steward Perspective");
		navigateFromLeftPane("Inbox");
		applyFilter(TestConstants.FilterCriteria.Search, "Orchestra Quick Number", StringFormator.formatNbrToString(orchQuickNumber));
		clickOnButton("Take and start");		
	}


	public void validatePGConfirmationRejection(String projectsId,String orchQuickNumber, Map<String, Object> valuesToUpdate, boolean pgConfirmation) throws Exception {
		TransactionalDatasetPage transactionalDatasetPage = TransactionalDatasetPage.getTransactionalDatasetPageObject(driver);
		MDMHomePage dashboard = MDMHomePage.getMDMHomePageObject(driver);		

		// update the fields with user with PG Role
		login(TestConstants.UserRole.PG);
		String [] updateField = valuesToUpdate.get("Edit Fields").toString().split("\\|");
		Map<String,String> updatedVal =  editAssignment(projectsId, updateField, valuesToUpdate);


		// Switch to DSP role and review the changes.
		goToURL(ConfigurationManager.getInstance().getProperty("ui.dev.url"));
		userStartReview(orchQuickNumber);
		transactionalDatasetPage.validateTransactionalDatasheet(updatedVal);
		switchFrameToSearchElement(By.xpath("//button[normalize-space()='Changes accepted']"));
		if(pgConfirmation) {
			clickOnButton("Changes accepted");
			clickOnButton("OK");		
			Thread.sleep(10000);
		}
		else {
			clickOnButton("Changes Invalid");
			clickOnButton("OK");		
			Thread.sleep(10000);
			transactionalDatasetPage.enterRejectionComment("Rejection Comment");
		}		

		dashboard.navigateToProject(projectsId,"Projects",TestConstants.UserRole.DS);

		Map<String,String> valueOnMainTab = getDataOnMainTab();
		Map<String, String> createLeadDataOrchestra=CreateLeadPage.getCreateProjectObject(driver).getLeadDataOrchestra(projectsId);
		if(pgConfirmation) {
			Validator.verifyResult(valueOnMainTab.get("PG confirmations"), "Chief Communication Officer", " After review being accepted by DSP PG confirmation field should show Chief�1.Communication�Officer");
			for(String k : updatedVal.keySet()) {
				Validator.verifyResult(valueOnMainTab.get(k), updatedVal.get(k), k+" value should be updated.");
			}

			Validator.log(" ------ User validate the lead data in Orchestra. ------ ");			
			for(String k : updatedVal.keySet()) {
				Validator.verifyResult(createLeadDataOrchestra.get(k), updatedVal.get(k), k+" value should be updated.");
			}

		}
		else {
			Validator.verifyResult(valueOnMainTab.get("PG rejections"), "Chief Communication Officer", " After review being rejected by DSP PG rejection field should show Chief�1.Communication�Officer");
			for(String k : updatedVal.keySet()) {
				Validator.verifyResult(valueOnMainTab.get(k).equalsIgnoreCase(updatedVal.get(k)),false, k+" value should not be updated in case of rejection.");
			}
			Validator.log(" ------ User validate the lead data in Orchestra. ------ ");	
			for(String k : updatedVal.keySet()) {
				Validator.verifyResult(createLeadDataOrchestra.get(k).equalsIgnoreCase(updatedVal.get(k)),false, k+" value should not be updated in case of rejection.");
			}
		}
	}


	public void validateConfirmAssignment(String orchestraQuickNbr,Map<String,Object> data) throws Exception {
		FeesPage feeTab = FeesPage.getFeesPageObject(driver);
		LegalEntitiesPage legalEntity = LegalEntitiesPage.getLegalEntitiesPageObject(driver);
		
		switchFrameToSearchElement(By.xpath("//td[normalize-space()='Projects ID']"));
		Validator.log("----- User select Assignment Confirmed radio button. -----");
		setFieldValue("Assignment Confirmed", "Yes");
		clickOnButton("Save");
		
		Validator.log("----- User validate the expected error message. -----");
		String[] expectedError =ErrorMessages.CONFIRMASSIGNMENT_ERROR;
		String[] actualError = getDisplayedErrorMessage().toArray(new String[0]);
		Validator.verifyArray(actualError, expectedError, "All the expected Error Messages should be displayed.");	
		
		feeTab.setFeesData(data);
		legalEntity.setLegalEntities(data);
		
		selectTab("Main");
		clickOnButton("Save");
		Thread.sleep(8000);
		// validate that the data of main tab is synced in Orchestra
		Map<String, String> dataOnMainTab = getDataOnMainTab();
		Validator.verifyResult(dataOnMainTab.get("Assignment Confirmed"), "Yes", "After Confirm Assignment Yes should be displayed in Main tab for Assignment Confirmed");
		Validator.verifyResult(dataOnMainTab.get("Assignment Confirmed Date"), getAssignmentConfirmationDateOrchestra(orchestraQuickNbr), "After Confirm Assignment correct date should be displayed in Main tab for Assignment Confirmed Date");
		
		feeTab.validateFeesGridData(orchestraQuickNbr);
		Validator.log(" ------ User validate the Legal Entitiess tab after Confirm Assignments. ------ ");
		selectTab("Legal Entities");
		legalEntity.validateLegalEntitiesGrid(true);
	}


	
	public List<String> getDisplayedErrorMessage() throws IOException {
		if(errorMsgCollapsibleBlockIdfr().getAttribute("title").equalsIgnoreCase("expand")) {
			click(errorMsgCollapsibleBlockIdfr());
		}
		
		List<String> errorList = new ArrayList<>();
		errorIdfr().forEach(x-> errorList.add(x.getText().trim()));
		
		String screenshot = ScreenshotUtil.takeFullPageScreenshot(driver, "ErrorMsg");
		Validator.log("Expected Error Message",errorList,screenshot);
		
		return errorList;
	}



	public void validateCloseAssignment(String projectsID) throws Exception {
		selectTab("Main");
		setFieldValue("Project Outcome Status", "Report submitted and complete");
		clickOnButton("Save");
		
		MDMHomePage dashboard = MDMHomePage.getMDMHomePageObject(driver);
		dashboard.performAction("Close Assignment");
		
		clickOnButton("Accept");
		clickOnButton("OK");
		Thread.sleep(10000);
		
		Map<String, String> dataOnMainTab = getDataOnMainTab();
		Map<String, String> dataOnMainTabOrch = CreateLeadPage.getCreateProjectObject(driver).getLeadDataOrchestra(projectsID);
		
		
		Validator.log("----- User validate that the data is synced in Orchestra. -----");
		Validator.verifyResult(dataOnMainTab.get("Status"), dataOnMainTabOrch.get("Status"), "After Close Assignment CLOSED should be displayed in Main tab for Status field.");
		Validator.verifyResult(dataOnMainTab.get("Closed Date"), dataOnMainTabOrch.get("Closed Date"), "After Close Assignment close date should be displayed in Main tab for Close Date field.");
		
	}







}
