package com.mdm.ui.pages;

import java.io.IOException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import com.mdm.database.DatabaseUtil;
import com.mdm.ui.ElementWaitUtil;
import com.mdm.ui.JSUtil;
import com.mdm.ui.ScreenshotUtil;
import com.mdm.ui.common.BasePage;
import com.mdm.ui.constants.TestConstants;
import com.mdm.ui.constants.SQLQueries;
import com.mdm.validation.Validator;

public class CreateLeadPage extends BasePage {

	//public Map<String, List<String>> expectedData;
	private static CreateLeadPage pageCreateProject = null;
	Map<String, Object> companyTableData;
	private CreateLeadPage(WebDriver driver) throws Exception {
		super(driver);
		this.driver = driver;
		//expectedData = new ExcelUtil().readExcelByQuery("Select * from CreateLead");

	}

	public synchronized static CreateLeadPage getCreateProjectObject(WebDriver driver) throws Exception {
		if (pageCreateProject == null) {
			pageCreateProject = new CreateLeadPage(driver);
		}
		return pageCreateProject;
	}

	private WebElement getOrchestraQuickIdfr() {
		return driver.findElement(By.xpath("//*[normalize-space()='Orchestra Quick Number']/ancestor::td/following-sibling::td[@class='ebx_Input']"));
	}

	public void switchFrame() {
		switchFrameById("ebx-legacy-component");
		//ElementWaitUtil.waitForLoaderToDisappear(driver,driver.findElement(By.id("ebx_LoadingLayerContent")));
	}

	public String getCreateLeadPageURL(String...clientCompany) throws Exception {

		String mdmCustomerID;
		if(clientCompany.length==0) {
			mdmCustomerID = DatabaseUtil.dbContext().getRecordAsMap(MessageFormat.format(SQLQueries.getMDMCustomerIDQuery,"Test Automation Company 1")).get(0).get("MDMCustomerID").toString();
		}
		else {
			mdmCustomerID = DatabaseUtil.dbContext().getRecordAsMap(MessageFormat.format(SQLQueries.getMDMCustomerIDQuery,clientCompany[0])).get(0).get("MDMCustomerID").toString();
		}

		String createLeadURL = DatabaseUtil.dbContext().getRecordAsMap(SQLQueries.getCreateLeadURLQuery).get(0).get("CreateLeadURL").toString(); 		
		return MessageFormat.format(TestConstants.UIUrls.getCreateLeadUri, createLeadURL,mdmCustomerID);

	}

	public void navigateToLeadCreation(String...clientCompany) throws Exception {
		goToURL(getCreateLeadPageURL(clientCompany));
		switchFrame();
	}

	public String getpcSwfDB(String companyName) throws Exception {
		String pvtCap= DatabaseUtil.dbContext().getRecordAsMap(MessageFormat.format(SQLQueries.getMDMCustomerIDQuery,companyName)).get(0).get("PrivateCapital").toString();
		if(pvtCap!=null) {
			if(String.valueOf(pvtCap).equals("0")) {
				return "No";
			}else {
				return DatabaseUtil.dbContext().getRecordAsMap(MessageFormat.format(SQLQueries.getPrivateCapitalTypeQuery,pvtCap)).get(0).get("Description").toString();
			}
		}else {
			return null;
		}
	}

	public Map<String,String> setProjectsValue(Map<String, Object> expectedData) throws InterruptedException, IOException {
		switchFrameToSearchElement(By.xpath("//td[normalize-space()='Projects ID']"));
		String[] fields = {"Lead Consultant","Type","Division","Project/Position","Local Language Position","Position Based", 
				"Practice Group 1","Practice Sub Group 1","Practice Group 2","Practice Subgroup 2","Function", 
				"PC/SWF","Family Business","Leadership Advisory","Executing Office","Originating Office",
				"Venture Engine","Confidential","VAT Number"};
		Map<String,String> map = new HashMap<>();

		for (String f : fields) {
			map.put(f, expectedData.get(f).toString().trim());
			setFieldValue(f, expectedData.get(f).toString());
		}

		String screenshot = ScreenshotUtil.takeFullPageScreenshot(driver, "setProjectsValue");
		Validator.log("User fills all the data to create the lead.",map,screenshot);
		clickOnButton("Save");
		Thread.sleep(10000);
		return map;
	}

	public Map<String, String> getProjectsValue() throws IOException{
		clickOnButton("Revert");
		ElementWaitUtil.waitForElementToBeVisible(driver, getOrchestraQuickIdfr());
		Map<String,String> map = new HashMap<>();
		for (String name : getFieldNameList()) {			
			map.put(name, getFieldValue(name));
		}		
		String screenshot = ScreenshotUtil.takeFullPageScreenshot(driver, "getProjectsValue");
		Validator.log("User reads all the data from project-> main tab for the created lead.",map,screenshot);
		return map;
	}

	public Map<String, String> getLeadDataOrchestra(String projectsId) throws Exception{
		Map<String,String> map = new HashMap<>();
		String id=projectsId.replaceAll("[^0-9]", "");
		String query = SQLQueries.getCreateLeadData_Orchestra_Query+id;
		Map<String, Object> d= DatabaseUtil.dbContext().getRecordAsMap(query).get(0);
		d.keySet().forEach(x ->{
			if(d.get(x) != null) {
				map.put(x, d.get(x).toString().trim());
			}else {
				map.put(x, "");
			}
		});
		return map;		
	}

	private List<WebElement> errorMsgIdfr() {
		return driver.findElements(By.xpath("//div[@class='ebx_ContainerWithTextPadding ebx_WorkspaceFormHeaderValidationMessages']//li"));
	}

	public List<String> getDisplayedErrorMsg(){
		List<String> message = new ArrayList<>();

		WebElement title = driver.findElement(By.xpath("//button[contains(@id,'ExpandCollapse')]"));
		JSUtil.getInstance(driver).scrollElementIntoView(title);
		if(title.getAttribute("title").equalsIgnoreCase("expand"))
			click(title);

		for (WebElement ele : errorMsgIdfr()) {			
			message.add(ele.getText().trim());
		}
		return message;
	}

	public boolean isMainTabDisplayed() {
		try {
			WebElement ele = driver.findElement(By.id("ebx_WorkspaceFormTabview"));
			return ele.isDisplayed();
		} catch (Exception e) {
			return false;
		}
	}

	public void validateError(String expectedError) throws IOException {
		List<String> actualError = getDisplayedErrorMsg();
		String[] exErr = expectedError.split("\\|");
		String imgPath = ScreenshotUtil.takeFullPageScreenshot(driver, "ErrorImg");
		Validator.log("User reads all the error on create lead Page",actualError,imgPath);
		Validator.verifyResult(actualError, Arrays.asList(exErr), "Expected error message should be displayed.");
	}

	public static void main(String[] args) {

		String a = "Test|t";
		String b[] = a.split("\\|");
		System.out.println(Arrays.asList(b));
	}

}
