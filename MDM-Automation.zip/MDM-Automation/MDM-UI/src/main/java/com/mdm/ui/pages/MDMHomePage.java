package com.mdm.ui.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import com.mdm.ui.common.BasePage;
import com.mdm.ui.constants.TestConstants;
import com.mdm.ui.utils.ReadGridData;
import com.mdm.validation.Validator;

public class MDMHomePage extends BasePage {

	private static MDMHomePage mDMHomePage;
	public MDMHomePage(WebDriver driver) {
		super(driver);
		this.driver=driver;
	}

	public synchronized static MDMHomePage getMDMHomePageObject(WebDriver driver){
		if (mDMHomePage == null) {
			mDMHomePage = new MDMHomePage(driver);
		}
		return mDMHomePage;
	}

	public void navigateToProject(String projectsId, String leftPaneOptn, TestConstants.UserRole userPerspective) throws InterruptedException{
		
		selectPersepective(userPerspective.roleDesc());
		navigateFromLeftPane(leftPaneOptn);
		applyFilter(TestConstants.FilterCriteria.Search, "Projects ID", projectsId);
		navigateFromGrid(projectsId);
	}

	private WebElement getActionBtnIdfr() {
		return driver.findElement(By.xpath("//div[@id='ebx_WorkspaceToolbar']//button[normalize-space(text())='Actions']"));
	}

	private WebElement getActionBtnOptnIdfr(String optn) {
		return driver.findElement(By.xpath("(//a[normalize-space(text())='"+optn+"']) | (//span[normalize-space(text())='"+optn+"']/ancestor::a)"));
	}

	public void performAction(String optionToSelect) throws InterruptedException {
		click(getActionBtnIdfr());
		click(getActionBtnOptnIdfr(optionToSelect));
		Thread.sleep(45000);
	}

	public void validateGridAfterDSReview(String projectsId) throws Exception {
		login(TestConstants.UserRole.PG);
		navigateFromLeftPane("Assignments");
		applyFilter(TestConstants.FilterCriteria.Search, "Projects ID", projectsId);
		Validator.log("-------- User Validate the data displayed in the grid -------");
		Validator.verifyResult(ReadGridData.getInstance(driver).isGridEmpty(), true, " No Records found. should be displayed in the Grid");
	}
	
}
