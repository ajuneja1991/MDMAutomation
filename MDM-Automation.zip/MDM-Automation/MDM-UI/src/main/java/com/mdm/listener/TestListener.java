package com.mdm.listener;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import com.mdm.reporting.ExtentManager;

public class TestListener implements ITestListener{

	@Override
	public void onTestStart(ITestResult result) {}

	@Override
	public void onTestSuccess(ITestResult result) {}

	@Override
	public void onTestFailure(ITestResult result) {}

	@Override
	public void onTestSkipped(ITestResult result) {
		ExtentManager.createTestNode(result.getTestClass().getRealClass().getSimpleName(), result.getName(),
				result.getMethod().getDescription());
		ExtentManager.logger().skip("This Test Case Skipped!");
		
	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {}

	@Override
	public void onStart(ITestContext context) {}

	@Override
	public void onFinish(ITestContext context) {}

}
