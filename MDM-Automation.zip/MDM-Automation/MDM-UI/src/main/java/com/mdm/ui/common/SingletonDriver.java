package com.mdm.ui.common;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SingletonDriver {

	private static ChromeDriver driver;
	@SuppressWarnings("unused")
	private final Log logger = LogFactory.getLog(SingletonDriver.class);
	
	private SingletonDriver() {
	}

	public static WebDriver getSingletonInstance() {
		if (null == driver) {
			System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			
		}
		return driver;
	}
	
	

}
