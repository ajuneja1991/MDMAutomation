package com.mdm.ui.pages;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.mdm.ui.common.BasePage;
import com.mdm.ui.constants.TestConstants;
import com.mdm.ui.utils.ReadGridData;
import com.mdm.validation.Validator;

public class LegalEntitiesPage extends BasePage  {

	private static LegalEntitiesPage legalEntitiesPage;
	public LegalEntitiesPage(WebDriver driver) {
		super(driver);
		this.driver=driver;
	}

	public synchronized static LegalEntitiesPage getLegalEntitiesPageObject(WebDriver driver) {
		if (legalEntitiesPage == null) {
			legalEntitiesPage = new LegalEntitiesPage(driver);
		}
		return legalEntitiesPage;
	}

	public void validateLegalEntitiesGrid(boolean...shouldHaveData) {
		boolean flag = shouldHaveData.length ==0 ? false: shouldHaveData[0];
		Validator.log("-------- User Validate the legal Entity Grid Data from Orchestra -------");

		List<String> actualHeader = ReadGridData.getInstance(driver).getHeader();
		List<String> expectedHeader =Arrays.asList( TestConstants.getLegalEntitiesGridHeader);
		Validator.verifyResult(actualHeader, expectedHeader, "All the expected columns should be displayed on Legal Entity Tab grid.");
		Validator.log("-------- User Validate the data displayed in the grid -------");			
		Validator.verifyResult(!ReadGridData.getInstance(driver).isGridEmpty(), flag, " Data in the Grid is validated.");	
		
	}


	public void setLegalEntities(Map<String, Object> data) throws InterruptedException, IOException {
		try {
			selectTab("Legal Entities");
			click(driver.findElement(By.xpath("//button[@title='Create a record']")));
			String[] fieldName = {"Legal Entity Type","Legal Entity"};
			switchFrameById("ebx_InternalPopup_frame");
			MainTabPage.getMainTabObject(driver).updateProjectsValue(fieldName, data);
			clickOnButton("Close");
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}


	}

}
