package com.mdm.ui.common;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.Method;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.mdm.configuration.ConfigurationManager;
import com.mdm.directory.DirectoryUtil;
import com.mdm.listener.TestListener;
import com.mdm.reporting.ExtentManager;
import com.mdm.ui.ScreenshotUtil;
import com.mdm.validation.Validator;


/**
 * This is Base Test class containing testNg annotation, controls and invocations 
 * NOTE: All the test files need to extend this class in order to get the driver instance.
 * 
 * @author Vivek Gupta
 *
 *
 */
@Listeners(TestListener.class)
public class BaseTest {

	private static WebDriver driver;
	private final String extentReportFolder = ConfigurationManager.getInstance().getProperty("ui.current.report"); //System.getProperty("user.dir") + "\\ExtentReports";
	private final String reportArchiveFolder =ConfigurationManager.getInstance().getProperty("ui.archive.report"); //System.getProperty("user.dir") + "\\ArchiveReports";

	@BeforeSuite
	public void beforeSuite() throws FileNotFoundException {
		driver = SingletonDriver.getSingletonInstance();
		ExtentManager.getReporter();

		// keep this line after ExtentManager.getReporter(); so that Report folders can be created for new setups 
		DirectoryUtil.moveFile(extentReportFolder, reportArchiveFolder);

	}

	@BeforeClass
	public void beforeClass() {
		String className = this.getClass().getSimpleName();
		ExtentManager.createTestClassNode(className);
	}

	@BeforeMethod
	public void beforeMethod(Method method) {
		ExtentManager.createTestNode(this.getClass().getSimpleName(), method.getName(),
				method.getAnnotation(Test.class).description());
	}

	@AfterMethod
	public void afterMethod(ITestResult result) throws IOException {
		resultLogger(result);
	}

	@AfterSuite
	public void afterSuite() {
		ExtentManager.writeTest();
		if (null != driver) {
			driver.close();
			driver.quit();
		}
	}

	public WebDriver getDriver() {
		return driver;
	}

	private static void resultLogger(ITestResult result) throws IOException {

		switch (result.getStatus()) {
		case ITestResult.SUCCESS:

			ExtentManager.logger().pass("This Test Case Passes!");
			break;
		case ITestResult.FAILURE:
			if (result.getThrowable().getStackTrace().length > 0) {
				String screenshot = ScreenshotUtil.takeFullPageScreenshot(driver, "Error");
				Validator.log("Test Case -> "+result.getName()+" has Failed.",result.getThrowable().getMessage(),screenshot);
				ExtentManager.logger().log(Status.FAIL, result.getThrowable().getMessage());
			}
			ExtentManager.logger().fail("This Test Case Failed!");
			break;
		case ITestResult.SKIP:
			ExtentManager.logger().skip("This Test Case Skipped!");
			break;
		default:
			break;
		}
	}

}
