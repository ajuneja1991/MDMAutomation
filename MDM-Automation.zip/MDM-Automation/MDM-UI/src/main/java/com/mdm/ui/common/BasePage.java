package com.mdm.ui.common;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.mdm.configuration.ConfigurationManager;
import com.mdm.encryption.EncryptionUtil;
import com.mdm.ui.DropdownUtil;
import com.mdm.ui.ElementWaitUtil;
import com.mdm.ui.JSUtil;
import com.mdm.ui.constants.TestConstants;
import com.mdm.ui.constants.TestConstants.FieldType;
import com.mdm.ui.constants.TestConstants.FilterCriteria;
import com.mdm.validation.Validator;

/**
 * This class contain all the common method for different actions to be performed on UI 
 * 
 * @author Vivek Gupta
 *
 *
 */
public class BasePage {


	private WebElement getFieldIdfr(String fieldName) {
		return driver.findElement(By.xpath("//*[normalize-space()='"+fieldName+"']/ancestor::td/following-sibling::td[@class='ebx_Input']"));
	}

	private WebElement getButtonIdfr(String buttonName) {
		switchFrameToSearchElement(By.xpath("//button[normalize-space()='"+buttonName+"']"));
		List<WebElement> ele =  driver.findElements(By.xpath("//button[normalize-space()='"+buttonName+"']"));
		return ele.get(ele.size()-1);
	}

	private WebElement getdropdownIdfr(String fieldName) {
		return getFieldIdfr(fieldName).findElement(By.xpath(".//input[@type='text']"));
	}

	private WebElement getTextBoxIdfr(String fieldName) {		
		return getFieldIdfr(fieldName).findElement(By.xpath(".//*[../child::input or ../child::textarea]"));
	}

	private WebElement getRadioBtnIdfr(String fieldName, String optn) {
		return getFieldIdfr(fieldName).findElement(By.xpath(".//input[@value='"+optn+"']"));
	}

	private WebElement getSelectedRadioBtnIdfr(String fieldName) {
		return getFieldIdfr(fieldName).findElement(By.xpath(".//input[@checked='checked']/parent::label"));
	}

	private WebElement getTabIdfr(String tabName) {
		//driver.switchTo().defaultContent();
		//driver.switchTo().frame("ebx-legacy-component");
		switchFrameToSearchElement(By.xpath("//em/descendant-or-self::*[normalize-space(text())='"+tabName+"']"));
		return driver.findElement(By.xpath("//em/descendant-or-self::*[normalize-space(text())='"+tabName+"']"));
	}

	private List<WebElement> getFieldsOnPageIdfr(){
		return driver.findElements(By.xpath("//td[@class='ebx_Label']//label"));
	}

	private WebElement getFilterBtnIdfr() {
		return driver.findElement(By.id("ebx_filtersButton"));
	}

	private WebElement leftPaneNavigationIdfr(String navigateToOption) {
		return driver.findElement(By.xpath("//span[normalize-space()='"+navigateToOption+"']//ancestor::a[@href]"));
	}

	private WebElement selectPerspectiveBtnIdfr() {
		return driver.findElement(By.xpath("//button[@title='Select perspective']"));
	}
	private WebElement perspectiveOptnIdfr(String optn) {
		return driver.findElement(By.xpath("//li//span[normalize-space()='"+optn+"']"));
	}

	private WebElement getFilterSectionExpandCollapseIdfr(String sectionName) {
		return driver.findElement(By.xpath("//label[normalize-space(text())='"+sectionName+"']/button"));
	}

	private WebElement getProjectRowIdfr(String projectsId) {
		return driver.findElement(By.xpath("//td/div[text()='"+projectsId+"']"));
	}
	
	//###################################################################################
	protected WebDriver driver;

	/**
	 * Base Page constructor to initialize driver instance.
	 * @param driver
	 */
	public BasePage(WebDriver driver) {
		this.driver = driver;
	}

	/**
	 * Method to navigate to a specified URL
	 * @param url
	 * @throws InterruptedException
	 */
	public void goToURL(String url) throws InterruptedException {
		driver.navigate().to(url);
		Thread.sleep(10000);
	}

	/**
	 * Method to switch frame on UI by frame id
	 * @param frameId
	 */
	public void switchFrameById(String frameId) {
		ElementWaitUtil.getFluentWait(driver).until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.id(frameId)));
	}

	/**
	 * Method to switch frame on UI by frame xpath
	 * @param frameId
	 */	
	public void switchFrame(By by) 
	{
		ElementWaitUtil.getFluentWait(driver).until(ExpectedConditions.
				frameToBeAvailableAndSwitchToIt(by)); 
	}


	private String getLabelValue(String fieldName) {
		WebElement ele = getFieldIdfr(fieldName);
		return ele.getText().trim();
	}

	protected void selectDropdown(String dropdownName, String value) {	
		DropdownUtil.getInstance(driver, getdropdownIdfr(dropdownName)).selectDropdown(value);
	}

	public String getValueInDropdown(String dropdownName) {
		return DropdownUtil.getInstance(driver, getdropdownIdfr(dropdownName)).getValueInDropdown();
	}

	protected void setValueInTextBox(String fieldName, String value) {
		JSUtil.getInstance(driver).scrollElementIntoView(getTextBoxIdfr(fieldName));
		ElementWaitUtil.waitForElementToBeVisible(driver,getTextBoxIdfr(fieldName));
		getTextBoxIdfr(fieldName).clear();
		getTextBoxIdfr(fieldName).sendKeys(value,Keys.TAB);
	}

	private String getTextBoxValue(String fieldName) {
		JSUtil.getInstance(driver).scrollElementIntoView(getTextBoxIdfr(fieldName));
		ElementWaitUtil.waitForElementToBeVisible(driver,getTextBoxIdfr(fieldName));
		return getTextBoxIdfr(fieldName).getAttribute("value");
	}

	private void setRadioBtn(String fieldName, String value) {
		String optn = value.equalsIgnoreCase("Yes") || value.equalsIgnoreCase("Y") || value.equalsIgnoreCase("true") ?"true":"false";
		click(getRadioBtnIdfr(fieldName,optn));
	}

	private String getSelectedRadioBtn(String fieldName) {
		JSUtil.getInstance(driver).scrollElementIntoView(getSelectedRadioBtnIdfr(fieldName));
		return getSelectedRadioBtnIdfr(fieldName).getText().trim();
	}

	/**
	 * Method to click on a button by passing displayed button name
	 * @param buttonName
	 */
	public void clickOnButton(String buttonName) {		
		click(getButtonIdfr(buttonName));
	}

	/**
	 * Method to select a tab on the UI
	 * @param tabName
	 */
	public void selectTab(String tabName) {
		Validator.log("User Clicks on "+tabName+" Tab.");		
		click(getTabIdfr(tabName));
	}

	/**
	 * Method to get the name of all the fields displayed in a form on UI
	 * @return
	 */
	public List<String> getFieldNameList(){
		List<String> result = new ArrayList<>();
		getFieldsOnPageIdfr().forEach(x-> {JSUtil.getInstance(driver).scrollElementIntoView(x);		
		result.add(x.getText().trim());}
				);
		return result;
	}

	/**
	 * Click method to click on web element
	 * @param el
	 */	
	public void click(WebElement el) {
		try {
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", el);			
			Thread.sleep(1000);
		}catch (InterruptedException e) {
			// Restore interrupted state...
			Thread.currentThread().interrupt();		  
		} catch (Exception e) {
			JSUtil.getInstance(driver).scrollElementIntoView(el);
			el.click();
		}
	}

	/**
	 * Method to refresh the web page
	 * @throws InterruptedException
	 */
	public void refresh() throws InterruptedException {
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));
		driver.navigate().refresh();
		Thread.sleep(4000);	
	}

	/**
	 * This method sets the value for the specified field in the web form.
	 * @param fieldName
	 * @param value
	 */
	public void setFieldValue(String fieldName, String value) {

		FieldType field = getFieldType(fieldName);
		if(field ==null) {
			throw new NullPointerException("Did not get field type for field-> "+fieldName);
		}
		else {
			switch (field) {
			case DROPDOWN:
				selectDropdown(fieldName, value);
				break;

			case INPUT:
			case TEXTBOX:
				setValueInTextBox(fieldName, value);
				break;

			case RADIO:
				setRadioBtn(fieldName, value);
				break;

			default:
				selectDropdown(fieldName, value);
				break;
			}
		}
	}

	/**
	 * This method returns the value of the field in the form displayed on the screen.
	 * @param fieldName
	 * @return
	 */
	public String getFieldValue(String fieldName) {
		FieldType field = getFieldType(fieldName);
		String result;
		if(field ==null) {
			throw new NullPointerException("Did not get field type for field-> "+fieldName);
		}
		else {
			switch (field) {
			case DROPDOWN:
				result= getValueInDropdown(fieldName).trim();
				break;

			case INPUT:
			case TEXTBOX:
				result= getTextBoxValue(fieldName).trim();
				break;

			case RADIO:
				result= getSelectedRadioBtn(fieldName).trim();
				break;
			case LABEL:
				result= getLabelValue(fieldName).trim();
				break;
			default:
				result= getValueInDropdown(fieldName).trim();
				break;
			}
		}
		return result;
	}

	private FieldType getFieldType(String fieldName) {
		System.out.println();
		List<WebElement> elements =  getFieldIdfr(fieldName).findElements(By.xpath(".//*"));
		List<String> nodes = new ArrayList<>();
		FieldType fieldType = null;
		for (WebElement e : elements) {
			nodes.add(e.getTagName());
		}
		if(nodes.contains(TestConstants.TEXTAREA)) {
			fieldType = FieldType.TEXTBOX;
		}
		if(nodes.contains(TestConstants.INPUT) && nodes.contains(TestConstants.BUTTON)) {
			fieldType=FieldType.DROPDOWN;
		}
		if(nodes.contains(TestConstants.INPUT) && !nodes.contains(TestConstants.BUTTON) && !nodes.contains(TestConstants.TABLE)) {
			fieldType=FieldType.INPUT;
		}
		if(nodes.contains(TestConstants.INPUT) && nodes.contains(TestConstants.TABLE)) {
			fieldType=FieldType.RADIO;
		}
		if((nodes.contains(TestConstants.SPAN)||nodes.contains(TestConstants.DIV)) && !nodes.contains(TestConstants.INPUT) && !nodes.contains(TestConstants.TABLE)&& !nodes.contains(TestConstants.TEXTAREA)) {
			fieldType=FieldType.LABEL;
		}
		if(nodes.contains("ol")) {
			fieldType=FieldType.LABEL;
		}
		return fieldType;
	}

	/**
	 * Returns the message displayed in the opened pop up.
	 * @return
	 */
	public String getPopupMsg() {
		switchFrameToSearchElement(By.className("_ebx-notification-box_list"));
		return driver.findElement(By.className("_ebx-notification-box_list")).getText().trim();
	}

	/**
	 * Method to select filter displayed on the grid on dashboard as per the specified criteria.
	 * @param filterCriteria
	 * @param colName
	 * @param value
	 * 
	 * Syntax to use the method:
	 * 
	 * applyFilter(Testconstants.FilterCriteria.Search, "Projects ID", "<project id to filter the grid>")
	 * 
	 */	
	public void applyFilter(FilterCriteria filterCriteria, String colName, String value) {

		try {
			//switchFrameById("ebx-legacy-component");
			switchFrameToSearchElement(By.cssSelector("#ebx_filtersButton"));
			//click on the filter button to open the filter
			click(getFilterBtnIdfr());

			// click on the filter and expand it if not expanded.
			WebElement attbTitle = getFilterSectionExpandCollapseIdfr(filterCriteria.name());
			ElementWaitUtil.waitForElementToBeClickable(driver, attbTitle);

			if(attbTitle.getAttribute("title").equalsIgnoreCase("expand"))
				click(attbTitle);

			switch (filterCriteria) {
			case Search:
				WebElement dropdownEle = driver.findElement(By.xpath("//select[contains(@id,'ebx_SimpleSearchFilterNodeSelectorList_FILTER')]"));
				ElementWaitUtil.waitForElementToBeClickable(driver, dropdownEle);				
				DropdownUtil.getInstance(driver, dropdownEle).selectDropdownByVisibleText(colName);
				Thread.sleep(8000);
				WebElement inputEle= driver.findElement(By.xpath("//div[@class='ebx_FilterBlockBody']//span[normalize-space()='"+colName+"']/..//input"));				
				inputEle.sendKeys(value);
				click(driver.findElement(By.xpath("//div[@id='FILTER_0_filterBlock']//button[normalize-space()='Apply']")));
				break;

			case TextSearch:			
				driver.findElement(By.xpath("//input[@name='criteria']")).sendKeys(value);
				click(driver.findElement(By.xpath("//div[@id='FILTER_1_filterBlock']//button[normalize-space()='Apply']")));
				break;
			case ValidationSearch:
				driver.findElement(By.xpath("//input[@name='mesage']")).sendKeys(value);
				click(driver.findElement(By.xpath("//div[@id='FILTER_2_filterBlock']//button[normalize-space()='Apply']")));
				break;
			default:
				break;
			}

			//click on the filter button to close the filter
			click(getFilterBtnIdfr());
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * This method selects the user perspective on MDM dashboard
	 * @param prespectiveToSelect
	 * 
	 * e.g. Business User Perspective
	 * 		Data Steward Perspective
	 * @throws InterruptedException 
	 */
	public void selectPersepective(String perspectiveToSelect) throws InterruptedException {
		try {
			switchFrameToSearchElement(By.xpath("//button[@title='Select perspective']"));
			ElementWaitUtil.waitForElementToBeClickable(driver, selectPerspectiveBtnIdfr());
			click(selectPerspectiveBtnIdfr());
			ElementWaitUtil.waitForElementToBeClickable(driver, perspectiveOptnIdfr(perspectiveToSelect));
			click(perspectiveOptnIdfr(perspectiveToSelect));
			Thread.sleep(5000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	/**
	 * This method clicks on the options in the left Pane for the selected user Perspective.
	 * @param Pass the option name to click to e.g. Projects, Assignments Pending for Billing, Customers,
	 * Legal Entity, Dun & BradStreet Details for DSP 
	 * @throws InterruptedException 
	 */
	public void navigateFromLeftPane(String navigateToOption) throws InterruptedException {
		ElementWaitUtil.waitForElementToBeClickable(driver, leftPaneNavigationIdfr(navigateToOption));
		click(leftPaneNavigationIdfr(navigateToOption));
		Thread.sleep(5000);
		//ElementWaitUtil.waitForElementToBeVisible(driver, driver.findElement(By.id("ebx_WorkspaceContent")));
	}


	private void switchiFrame(By by) {
		try {			
			List<WebElement> iframes = driver.findElements(By.xpath("//iframe"));			
			for (int j=0; j<iframes.size();j++) {
				driver.switchTo().frame(j);
				int	 searchElement=driver.findElements(by).size();
				if(searchElement>0) {
					break;
				}else {
					switchiFrame(by);
				}		       
			}


		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void switchFrameToSearchElement(By by) {
		try {
			//System.out.println();
			//JavascriptExecutor jsExecutor = (JavascriptExecutor)driver;
			//Object currentFrame = jsExecutor.executeScript("return self.name");
			int	 searchElement=driver.findElements(by).size();
			if(searchElement==0) {
				driver.switchTo().defaultContent();
				switchiFrame(by);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	private List<WebElement> profileButtonIdfr() {
		return driver.findElements(By.xpath("//span[@class='_ebx-profile_button_contains_avatar_only']/button"));
	}		

	private WebElement loginPageIdfr() {
		return driver.findElement(By.className("_ebx-login-page_form_title"));
	}
	
	private WebElement usernameIdfr() {
		return driver.findElement(By.name("login"));
	}
	private WebElement passwordIdfr() {
		return driver.findElement(By.name("password"));
	}
	
	public void login(TestConstants.UserRole userRole) throws Exception {
		try {			
			goToURL(ConfigurationManager.getInstance().getProperty("ui.dev.url"));
			String userName = "ui.dev.username."+userRole.roleName();
			String password = "ui.dev.password."+userRole.roleName();
			if(!profileButtonIdfr().isEmpty()) {
			click(profileButtonIdfr().get(0));
			clickOnButton("Logout");
			Thread.sleep(5000);
			}
			login(ConfigurationManager.getInstance().getProperty(userName),new EncryptionUtil().decrypt(ConfigurationManager.getInstance().getProperty(password)));
		}
		catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}
	private void login(String username, String password) {
		try {
			ElementWaitUtil.waitForElementToBeEnabled(driver, loginPageIdfr());
			usernameIdfr().sendKeys(username);
			passwordIdfr().sendKeys(password);
			clickOnButton("Log in");
			ElementWaitUtil.waitForElementToBePresent(driver, By.xpath("//span[@class='_ebx-profile_button_contains_avatar_only']/button"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	

	/**
	 * Method clicks on fields in grid to navigate
	 * E.g. Projects ID, Fee ID e.tc.
	 * navigateFromGrid("28,567")
	 * @param valueToClick
	 * @throws InterruptedException
	 */
	public void navigateFromGrid(String valueToClick) throws InterruptedException {
		Actions action = new Actions(driver);
		action.doubleClick(getProjectRowIdfr(valueToClick)).build().perform();
		Thread.sleep(5000);
	}
	
}
