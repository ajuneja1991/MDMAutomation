package com.mdm.ui.pages;

import org.openqa.selenium.WebDriver;

import com.mdm.database.DatabaseUtil;
import com.mdm.ui.common.BasePage;
import com.mdm.ui.constants.SQLQueries;

public class TeamPage extends BasePage {

	private static TeamPage teamPage;
	public TeamPage(WebDriver driver) {
		super(driver);
		this.driver=driver;
	}

	public synchronized static TeamPage getTeamPageObject(WebDriver driver){
		if (teamPage == null) {
			teamPage = new TeamPage(driver);
		}
		return teamPage;
	}
	
	public Object[][] getTeamGridDataOrchestra(String projectId) {
		String id=projectId.replaceAll("[^0-9]", "");
		String query = SQLQueries.getTeamTab_Orchestra_Query+id;
		return DatabaseUtil.dbContext().getDataWithColumn(query);
	}
}
