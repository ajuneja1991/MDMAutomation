package com.mdm.ui.utils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.MoveTargetOutOfBoundsException;

import com.mdm.ui.ElementWaitUtil;

import lombok.Getter;
import lombok.Setter;

/***
 * 
 * Class with methods to read web tables on UI 
 * 
 * @author Vivek Gupta
 *
 *
 */
public class ReadGridData {

	private final static String table_Xpath = "//div[@class='yui-content']/div[not(contains(@class,'yui-hidden'))] | //div[@id='ebx_workspaceTable_container']";
	private final static String header_Xpath = ".//th//span[contains(@class,'ebx_nodeLabel')]";
	private final static String row_Xpath = ".//table[@class='ebx_tvMain']//tr[@class]";

	@Getter @Setter
	private WebElement tableIdfr;
	private WebDriver driver;
	private JavascriptExecutor jse;
	private ReadGridData(WebDriver driver) {
		this.driver = driver;
		try {
			jse = ((JavascriptExecutor) driver);		
			setTableIdfr(driver.findElement(By.xpath(table_Xpath)));
		} catch (StaleElementReferenceException e) {
			ElementWaitUtil.waitForPOMRefresh(driver.findElement(By.xpath(table_Xpath)));
			setTableIdfr(driver.findElement(By.xpath(table_Xpath)));
		}
	}
	private static ReadGridData myObj;
	public static ReadGridData getInstance(WebDriver driver){
		if(myObj == null){
			myObj = new ReadGridData(driver);
		}
		return myObj;
	}

	private List<WebElement> getRow(){
		
		try {
			return driver.findElement(By.xpath(table_Xpath)).findElements(By.xpath(row_Xpath));
		} catch (Exception e) {
			return Collections.emptyList();
		}
	}

	private WebElement getCell(int rowIndex, int colIndex) {
		WebElement ele= driver.findElement(By.xpath(table_Xpath)).findElement(By.xpath(".//table[@class='ebx_tvMain']//tr[@class]["+rowIndex+"]/td[not(contains(@style,'hidden'))]["+colIndex+"]"));
		jse.executeScript("arguments[0].scrollIntoView(true)", ele);
		return ele;
	}
	
	/**
	 * gives the index/column number of the column.
	 * 
	 * @param colName
	 * @return
	 */
	public int getColIndex(String colName) {
		return getHeader().indexOf(colName);
	}

	/**
	 * returns the number of rows
	 * @return
	 */
	public int getNbrOfRows() {
		return getRow().size();
	}
	
	/**
	 * get the list of column names displayed on the displayed table on the UI
	 * @return
	 */
	public List<String> getHeader(boolean...scroll){
		boolean s=scroll.length==0?true:scroll[0];
		List<String> colName = new ArrayList<>();
		int flag=0;
			try {
				List<WebElement> header = driver.findElement(By.xpath(table_Xpath)).findElements(By.xpath(header_Xpath));				
				
				for (WebElement x : header) {
					if(s)
						jse.executeScript("arguments[0].scrollIntoView(true)", x);
						
					colName.add(x.getText().trim());
				}				
			} catch (MoveTargetOutOfBoundsException e) {
				driver.navigate().refresh();
				flag++;
				if(flag<2)
					getHeader(false);
			}
			return colName;
	}
	
	/**
	 * reads the table data in and return in tabular form of [][]
	 * @return
	 */
	public String[][] getGridValue(){
		try {
			Object[] colName=  getHeader().toArray();
			List<WebElement> rows = getRow();

			String[][] grid = new String[rows.size()+1][colName.length];

			for(int i=0;i<colName.length;i++) {
				grid[0][i] = colName[i].toString();
			}

			for(int i=1; i<=rows.size();i++) {
				for(int j=0; j<colName.length;j++) {
					grid[i][j] = getCell(i, j+1).getText().trim();
				}
			}
			return grid;
		} catch (Exception e) {
			return null;
		}
	}
	
	/**
	 * return list of values under a column name
	 * @param columnName
	 * @return
	 */
	public List<String> getColumnValue(String columnName){
		int colIndex = getColIndex(columnName);
		List<String> value = new ArrayList<>();
		List<WebElement> rows = getRow();
		for(int i=1; i<=rows.size();i++) {
			Actions action = new Actions(driver);
			action.moveToElement(getCell(i, colIndex+1)).build().perform();
			value.add(getCell(i, colIndex+1).getText().trim());
		}
		return value;
	}
	
	public boolean isGridEmpty() {
		int row = getNbrOfRows();
		if(row==0)
			return true;
		else
			return false;
	}

}
