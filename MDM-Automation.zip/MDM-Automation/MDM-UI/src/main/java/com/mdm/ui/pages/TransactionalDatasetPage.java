package com.mdm.ui.pages;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.mdm.ui.common.BasePage;
import com.mdm.validation.Validator;

public class TransactionalDatasetPage extends BasePage  {

	private static TransactionalDatasetPage transactionalDatasetPage;
	public TransactionalDatasetPage(WebDriver driver) {
		super(driver);
		this.driver=driver;
	}
	
	public synchronized static TransactionalDatasetPage getTransactionalDatasetPageObject(WebDriver driver) {
		if (transactionalDatasetPage == null) {
			transactionalDatasetPage = new TransactionalDatasetPage(driver);
		}
		return transactionalDatasetPage;
	}

	private WebElement getViewOptnIdfr(String option) {
		return driver.findElement(By.xpath("//li/a[normalize-space()='"+option+"']"));
	}
	
	
	//==================================================================================================
	public void selectView(String option) {
		clickOnButton("View");
		click(getViewOptnIdfr(option));
	}
	
	public void validateTransactionalDatasheet(Map<String,String> valueToValidate) throws Exception {
		selectView("Hide similarities");
		Validator.verifyMap(getDisplayedChangesInTable(), valueToValidate, "All the values that has been updated should be displayed.");
	}

	private Map<String,String> getDisplayedChangesInTable(){
			String fieldXpath = "//td/div[@class='ebx_DataType ebx_foreign_key']/following-sibling::span";
			String valXpath =".//parent::td/following-sibling::td[3]";
			
			List<WebElement> fieldEle = driver.findElements(By.xpath(fieldXpath));
			Map<String,String> value = new HashMap<>();
			for (int i=0; i<fieldEle.size(); i++) {
				value.put(fieldEle.get(i).getText().trim(), fieldEle.get(i).findElement(By.xpath(valXpath)).getText().trim());
			}		
			return value;
	}
	
	private WebElement commentBoxIdfr() {
		return driver.findElement(By.xpath("//*[@id='ebx_UIMDMComponentSetComment']/textarea"));
	}
	
	public void enterRejectionComment(String comment) throws InterruptedException {
		try {
			switchFrameToSearchElement(By.xpath("//*[@id='ebx_UIMDMComponentSetComment']/textarea"));
			commentBoxIdfr().sendKeys(comment);
			clickOnButton("Save");
			Thread.sleep(5000);
			switchFrameToSearchElement(By.xpath("//*[@id='ebx_WorkspaceFormFooter']//button[normalize-space()='Changes Invalid']"));
			click(driver.findElement(By.xpath("//*[@id='ebx_WorkspaceFormFooter']//button[normalize-space()='Changes Invalid']")));
			Thread.sleep(10000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
