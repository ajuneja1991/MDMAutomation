package com.mdm.ui.constants;

/**
 * 
 * This class contains constant values like SQL Queries, exception messages, flags default value and other project constant values.
 * @author Vivek Gupta
 *
 */
public class TestConstants {

	public static final String[] getCreateLeadFieldsOrchestra = new String[]{			
			"Projects ID",
			"Projects Description",
			"Orchestra Quick Number",
			"Orchestra Quick Number Link",
			"Opened Date",
			"Lead Consultant",
			"Type",
			"Client Company",
			"Ultimate Parent Company",
			"Division",
			"Project/Position",
			"Local Language Position",
			"Position Based",
			"Status",
			"Practice Group 1",
			"Practice Sub Group 1",
			"Practice Group 2",
			"Practice Subgroup 2",
			"Function",
			"PC/SWF",
			"Family Business",
			"Leadership Advisory",
			"Executing Office",
			"Executing Region",
			"Originating Office",
			"Venture Engine",
			"Closed Date",
			"Elapsed Days",
			"Months To Close",
			"LOP Confirmed",
			"PG confirmations",
			"PG rejections",
			"Confidential",
			"VAT Number",
			"Contract Signed Date"
	};

	public static final String[] getProjectClientTeamDetailsGridHeader = new String[] {"ID",
			"Client Contact Indicator",
			"Client Finance Contact?",
			"Finance Can Contact?",
			"Person",
			"Position",	
			"Company",
			"Direct Line",	
			"Email Address",	
			"Created On",
			"Last Updated On",	
			"Created By",
			"Last Updated By",	
			"Data Source",
	"Orchestra Login Name"};

	public static final String[] getFeesGridHeader = new String[] {"Fees ID",
			"Zero Billing",	
			"Expenses Type",
			"Fee Currency",
			"Invoice Office",	
	"Referred"};

	public static final String[] getLegalEntitiesGridHeader = new String[] {"Customer Legal Entity ID",
			"Customer ID",
			"Legal Entity Type",
			"Legal Entity",
			"Created On",
			"Last Updated On",
			"Created By",
			"Last Updated By",
			"Data Source",
			"Orchestra Login Name",
			"Dun ID",
	"Sync to Invoice Details"};

	public static final String[] getLeadOutcomesGridHeader = new String[] {"Lead Outcome ID",
			"Lead Outcome",
			"Notes",
			"Assignment Number",
			"Created On",
			"Last Updated On",
			"Created By",
			"Last Updated By",	
			"Data Source",
	"Orchestra Login Name"};

	public static final String[] getLinkedDocumentsGridHeader = new String[] {"Document ID",
			"Document Type",	
			"Document URL",
			"Document Name",
			"Document Extension",	
			"Created On",
			"Last Updated On",
			"Created By",
			"Last Updated By",
			"Data Source",
			"Orchestra Login Name",
			"Document Edited Time",
			"Docusigned Version",
	"Assignment ID"};

	public static final String NO_RECORDS = "No records found.";

	public static final String TEXTAREA ="textarea";
	public static final String INPUT ="input";
	public static final String BUTTON ="button";
	public static final String TABLE ="table";
	public static final String SPAN ="span";
	public static final String DIV ="div";

	public enum FilterCriteria {

		Search("Search"),
		TextSearch("Text search"), 
		ValidationSearch("Validation search");

		private String criteriaName;
		FilterCriteria(String criteriaName) {
			this.criteriaName = criteriaName;
		}
		public String criteriaName() { return criteriaName; }

	}
	
	public enum UserRole {

		PG("PG","Perspective PG Specialists"),
		BU("BU","Business User Perspective"), 
		DS("DS","Data Steward Perspective");

		private String roleName;
		private String roleDesc;
		UserRole(String roleName, String roleDesc) {
			this.roleName = roleName;
			this.roleDesc = roleDesc;
		}
		public String roleName() { return roleName; }
		public String roleDesc() { return roleDesc; }

	}

	public enum FieldType {DROPDOWN,INPUT,TEXTBOX,RADIO,LABEL}
	
	public class UIUrls {
		private UIUrls() {
			throw new IllegalStateException("Can not create object of UIUrls class");
		}
		public static final String getCreateLeadUri= "{0}%5B.%2Fprojectsdescription%3D%221%22%20and%20.%2Fstatus%3D%221%22%20and%20.%2Fcustomerid%3D%22{1}%22%5D";

	}

}
