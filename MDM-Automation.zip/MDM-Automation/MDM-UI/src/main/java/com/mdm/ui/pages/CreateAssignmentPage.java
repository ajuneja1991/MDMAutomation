package com.mdm.ui.pages;

import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import com.mdm.configuration.ConfigurationManager;
import com.mdm.database.DatabaseUtil;
import com.mdm.ui.ScreenshotUtil;
import com.mdm.ui.common.BasePage;
import com.mdm.ui.constants.TestConstants;
import com.mdm.ui.constants.SQLQueries;
import com.mdm.validation.Validator;

public class CreateAssignmentPage extends BasePage {

	private static CreateAssignmentPage pageCreateAssignment = null;
	Map<String, Object> companyTableData;
	private CreateAssignmentPage(WebDriver driver){
		super(driver);
		this.driver = driver;

	}

	public synchronized static CreateAssignmentPage getCreateAssignmentPageObject(WebDriver driver){
		if (pageCreateAssignment == null) {
			pageCreateAssignment = new CreateAssignmentPage(driver);
		}
		return pageCreateAssignment;
	}

	public void navigateToAssignment(String projectId) throws Exception {
		MDMHomePage dashboard = MDMHomePage.getMDMHomePageObject(driver);
		goToURL(ConfigurationManager.getInstance().getProperty("ui.dev.url"));
		dashboard.navigateToProject(projectId,"Projects",TestConstants.UserRole.DS);
	}
	
	public Map<String,String> createAssignment(String projectId) throws Exception {

		MDMHomePage dashboard = MDMHomePage.getMDMHomePageObject(driver);
		MainTabPage mainTab = MainTabPage.getMainTabObject(driver);
		navigateToAssignment(projectId);
		dashboard.performAction("Create Assignment");
		
		Map<String,String> mainTabDataBeforeAccept = mainTab.getDataOnMainTab();
		clickOnButton("Save");
		switchFrameToSearchElement(By.xpath("//button[normalize-space()='Accept']"));
		clickOnButton("Accept");
		clickOnButton("OK");		
		Thread.sleep(20000);
		dashboard.navigateToProject(mainTabDataBeforeAccept.get("Projects ID"),"Projects",TestConstants.UserRole.DS);
		return mainTab.getDataOnMainTab();

	}

	public Map<String,String> updateAssignmentValue(String projectsId,Map<String, Object> expectedData) throws Exception {
		
		String[] fields = {"Type","Division","Project/Position","Local Language Position","Position Based", 
				"Practice Group 1","Practice Sub Group 1","Practice Group 2","Practice Subgroup 2","Function", 
				"PC/SWF","Family Business","VAT Number"};
		Map<String,String> map = new HashMap<>();

		for (String f : fields) {
			map.put(f, expectedData.get(f).toString().trim());
			setFieldValue(f, expectedData.get(f).toString());
		}

		String screenshot = ScreenshotUtil.takeFullPageScreenshot(driver, "setProjectsValue");
		Validator.log("User fills all the data to update an assignment.",map,screenshot);
		clickOnButton("Save");
		Thread.sleep(10000);
		return map;
	}

	public Map<String, String> getAssignmentDataOrchestra(String projectsId) throws Exception{
		Map<String,String> map = new HashMap<>();
		String id=projectsId.replaceAll("[^0-9]", "");
		String query = SQLQueries.getAssignment_Orchestra_Query+id;
		Map<String, Object> d= DatabaseUtil.dbContext().getRecordAsMap(query).get(0);
		d.keySet().forEach(x ->{
			if(d.get(x) != null) {
				map.put(x, d.get(x).toString().trim());
			}else {
				map.put(x, "");
			}
		});
		return map;		
	}

}
