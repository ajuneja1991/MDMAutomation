package com.mdm.ui.dataprovider;

import org.testng.annotations.DataProvider;

import com.codoid.products.exception.FilloException;
import com.mdm.excel.ExcelUtil;

public class DuplicateLeadDataProvider {

	@DataProvider (name = "createNewLead")
	public Object[][] createNewLead() throws FilloException{		
		return new ExcelUtil().readExcelData("Select * from CreateLead");
	} 


	@DataProvider (name = "duplicateLeadData")
	public Object[][] duplicateLeadData() throws FilloException{
		return new ExcelUtil().readExcelData("Select * from CreateDuplicateLead");
	} 


}
