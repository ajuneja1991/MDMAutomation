package com.mdm.ui.pages;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.WebDriver;

import com.mdm.ui.common.BasePage;
import com.mdm.ui.constants.TestConstants;
import com.mdm.ui.utils.ReadGridData;
import com.mdm.validation.Validator;

public class LinkedDocumentsPage extends BasePage  {

	private static LinkedDocumentsPage linkedDocumentsPage;
	public LinkedDocumentsPage(WebDriver driver) {
		super(driver);
		this.driver=driver;
	}
	
	public synchronized static LinkedDocumentsPage getLinkedDocumentsPageObject(WebDriver driver) {
		if (linkedDocumentsPage == null) {
			linkedDocumentsPage = new LinkedDocumentsPage(driver);
		}
		return linkedDocumentsPage;
	}

	public void validateLinkedDocumentsGrid() {
		Validator.log("-------- User Validate the default columns on the screen -------");
		List<String> actualHeader = ReadGridData.getInstance(driver).getHeader();
		List<String> expectedHeader =Arrays.asList( TestConstants.getLinkedDocumentsGridHeader);
		Validator.verifyResult(actualHeader, expectedHeader, "All the expected columns should be displayed on Linked Documents Tab grid for New Lead Created.");
	
		Validator.log("-------- User Validate the data displayed in the grid -------");
		Validator.verifyResult(ReadGridData.getInstance(driver).isGridEmpty(), true, " No Records found. should be displayed in the Grid");
	}

}
