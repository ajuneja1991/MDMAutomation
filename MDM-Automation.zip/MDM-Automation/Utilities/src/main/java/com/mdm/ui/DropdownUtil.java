package com.mdm.ui;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.google.common.base.Strings;

public class DropdownUtil {
	
	private Select osel;
	private static WebDriver driver;
	private static WebElement dropdownElement;
	private DropdownUtil(){
	}
	
	private static class LazyHolder
	{
		private static final DropdownUtil INSTANCE = new DropdownUtil();
	}

	public static DropdownUtil getInstance(WebDriver driver, WebElement element)
	{
		DropdownUtil.driver = driver;
		DropdownUtil.dropdownElement = element;
		return LazyHolder.INSTANCE;
	}
	
	/**
	 * Select all options that have a value matching the argument. That is, when given "foo" this
	 * would select an option like:<option value="foo">Bar</option>
	 * 
	 * NOTE: This method works only for dropdown with node Select in DOM
	 * 
	 * @param value
	 */
	public void selectDropdownByValue(String value) {
		osel = new Select(dropdownElement);
		osel.selectByValue(value);
	}
	
	/**
	 * Select all options that display text matching the argument. That is, when given "Bar" this
	 * would select an option like:<option value="foo">Bar</option>
	 * 
	 * NOTE: This method works only for dropdown with node Select in DOM
	 * @param value
	 */
	public void selectDropdownByVisibleText(String option) {
		osel = new Select(dropdownElement);
		osel.selectByVisibleText(option);
	}
	
	/**
	 * This method select the value in a drop down which does not have drop down node select and has a search box
	 * @param value : drop down option to select.
	 */
	public void selectDropdown(String value) {	

		if(!Strings.isNullOrEmpty(value)) {if(!value.equalsIgnoreCase("[not defined]")) {
		ElementWaitUtil.waitForElementToBeVisible(driver, dropdownElement);
		JSUtil.getInstance(driver).scrollElementIntoView(dropdownElement);
		dropdownElement.clear();
		dropdownElement.sendKeys(value);
		ElementWaitUtil.waitForDropDownLoadingBarToDisappear(driver);
		List<WebElement> valEle = driver.findElements(By.xpath("//div[@id='ebx_ISS_Results']/div/div"));
		
		if(valEle.size()>1) {
		for (WebElement webElement : valEle) {
			if(webElement.getText().trim().equalsIgnoreCase(value)) {
				JSUtil.getInstance(driver).scrollElementIntoView(webElement);
				webElement.click();
			}
		}
		}else
			dropdownElement.sendKeys(Keys.ENTER,Keys.TAB);
		}}
	}
	
	public String getValueInDropdown() {	
		ElementWaitUtil.waitForElementToBePresent(driver, dropdownElement,By.xpath("//input[@type='text']"));
		JSUtil.getInstance(driver).scrollElementIntoView(dropdownElement);
		return dropdownElement.getAttribute("value").trim();
	}

}
