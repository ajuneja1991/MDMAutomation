package com.mdm.validation;

import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.google.gson.Gson;
import com.mdm.array.ArraysUtil;
import com.mdm.array.PrettyPrintArray;
import com.mdm.hashmap.HashmapUtils;
import com.mdm.hashmap.PrettyPrintingMap;
import com.mdm.reporting.ExtentManager;
import com.mdm.ui.ScreenshotUtil;

import io.restassured.response.Response;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class Validator {

	private Validator() {
		throw new IllegalStateException("Can not create object for Validation class");
	}

	public static <T> void verifyResult(T actual, T expected, String... message) {

		boolean result = String.valueOf(actual).equals(String.valueOf(expected));
		if (result)
			ExtentManager.logger().log(Status.PASS, tableFormater(String.valueOf(actual), String.valueOf(expected),
					String.valueOf(message.length != 0 ? message[0] : "")));
		else
			ExtentManager.logger().log(Status.FAIL, tableFormater(String.valueOf(actual), String.valueOf(expected),
					String.valueOf(message.length != 0 ? message[0] : "")));

		Assert.assertEquals(actual, expected, String.valueOf(message.length != 0 ? message[0] : ""));

	}
	
	@SuppressWarnings("unchecked")
	public static <K,V> void verifyMap(Map<K,V> actual, Map<K,V> expected, String... message) throws Exception {

		log("Actual Value", new PrettyPrintingMap<String, String>((Map<String, String>) actual).toString());
		log("Expected Value", new PrettyPrintingMap<String, String>((Map<String, String>) expected).toString());
		boolean result =HashmapUtils.areEqual(actual, expected);
		if (result) {
			ExtentManager.logger().log(Status.PASS, tableFormater(actual.toString(),expected.toString(),
					String.valueOf(message.length != 0 ? message[0] : "")));}
		else {			
			ExtentManager.logger().log(Status.FAIL, tableFormater(String.valueOf(actual), String.valueOf(expected),
					String.valueOf(message.length != 0 ? message[0] : "")));
			
			List<String> mismatchVal =  HashmapUtils.mismatchInMap(actual, expected);
			ExtentManager.logger().log(Status.FAIL,mismatchVal.toString());
			
			}

		Assert.assertEquals(result, true, String.valueOf(message.length != 0 ? message[0] : ""));
	}
	
	
	public static <T> void verifyArray(T[][] actual, T[][] expected, String... message)
	{

		log("Actual Value", PrettyPrintArray.print(actual));
		log("Expected Value",PrettyPrintArray.print(expected));
		boolean result =Arrays.deepEquals(actual, expected);
		if (result) {
			ExtentManager.logger().log(Status.PASS, tableFormater(PrettyPrintArray.print(actual),PrettyPrintArray.print(expected),
					String.valueOf(message.length != 0 ? message[0] : "")));
			}
		else {			
			ExtentManager.logger().log(Status.FAIL, tableFormater(PrettyPrintArray.print(actual),PrettyPrintArray.print(expected),
					String.valueOf(message.length != 0 ? message[0] : "")));
			
			}
		Assert.assertEquals(result, true, String.valueOf(message.length != 0 ? message[0] : ""));
	}
	
	public static <T> void verifyArray(T[] actual, T[] expected, String... message)
	{
		System.out.println(actual);
		log("Actual Value", actual);
		log("Expected Value",expected);
		boolean result =ArraysUtil.equals(actual, expected);
		if (result) {
			ExtentManager.logger().log(Status.PASS, tableFormater(String.valueOf(actual),String.valueOf(expected),
					String.valueOf(message.length != 0 ? message[0] : "")));
			}
		else {			
			ExtentManager.logger().log(Status.FAIL, tableFormater(String.valueOf(actual),String.valueOf(expected),
					String.valueOf(message.length != 0 ? message[0] : "")));
			
			}
		Assert.assertEquals(result, true, String.valueOf(message.length != 0 ? message[0] : ""));
	}
	
	public static void verifySubSet(Map<String,String> superSet, Map<String,String> subSet, String message, String...label) throws Exception {

		boolean result = superSet.entrySet().containsAll(subSet.entrySet());
		if(label.length==0) {
			label =new String[]{"SUBSET","SUPERSET"};
		}
		if (result)
			ExtentManager.logger().log(Status.PASS, tableFormater(String.valueOf(subSet), String.valueOf(superSet),
					String.valueOf(message),label));
		else {
			ExtentManager.logger().log(Status.FAIL, tableFormater(String.valueOf(subSet), String.valueOf(superSet),
					String.valueOf(message),label));
			
			List<String> mismatchVal =  HashmapUtils.mismatchInSubsetNSuperset(subSet, superSet);
			ExtentManager.logger().log(Status.INFO,mismatchVal.toString());
		}
		Assert.assertEquals(result, true, String.valueOf(message));

	}

	public static void log(String logMessage) {
		ExtentManager.logger().log(Status.INFO, logMessage);
	}

	public static <T> void log(String label, T msg) {
		String logMessage = "<details><summary><B><font color=\"#3366BB\"><u>"+label+"</u></font></B></summary><pre>"+msg+"</pre></details>";
		ExtentManager.logger().log(Status.INFO, logMessage);
	}
	
	@SuppressWarnings("unchecked")
	public static <T> void log(String label, T msg, String screenshotPath) throws IOException {
		String log;
		if(msg.getClass()==HashMap.class) 
			log=new PrettyPrintingMap<String, String>((Map<String, String>) msg).toString();
		else
			log=String.valueOf(msg);
		
		String logMessage = "<details><summary><B><font color=\"#3366BB\"><u>"+label+"</u></font></B></summary><pre>"+log+"</pre></details>";
		ExtentManager.logger().info(logMessage);
		ExtentManager.logger().addScreenCaptureFromPath(screenshotPath);
	}
	
	public static <T> void logRequest(Class<T> cls) {		
		String jsonString = new Gson().toJson(cls);
		String logMessage = "<details><summary><B><font color=\"red\">REQUEST</font></B></summary><pre>"+jsonString+"</pre></details>";
		ExtentManager.logger().log(Status.INFO, logMessage);
	}

	public static void logResponse(Response response) {
		String respBody= response.getBody().asPrettyString();
		String logMessage = "<details><summary><B><font color=\"red\">RESPONSE</font></B></summary><pre>"+respBody+"</pre></details>";
		ExtentManager.logger().log(Status.INFO, logMessage);

	}

	public static void logWithScreenshot(WebDriver driver,String imgPath,Status status,String logMessage) throws Exception {
		String screenshotPath = ScreenshotUtil.takeScreenshot(driver, imgPath);
		ExtentManager.logger().log(status, logMessage,MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
	}

	private static String tableFormater(String actual, String expected, String msg,String...label) {

		String label1 = label.length>0 ? label[0]:"ACTUAL";
		String label2 = label.length==2 ? label[1]:"EXPECTED";
		return "<style>\r\n" + "#customers { border-collapse: collapse; width: 100%;\r\n"
				+ " border: 2px solid #1c87c9; }\r\n" + "#customers td, #customers th {\r\n"
				+ "  border: 1px solid #ddd;\r\n" + "  padding: 8px;\r\n" + "}\r\n" + "#customers th {\r\n"
				+ "  padding-top: 12px;\r\n" + "  padding-bottom: 12px;\r\n" + "  text-align: left;\r\n"
				+ "  background-color: #19222d;\r\n" + "  color: white; width:15%;" + "}\r\n" + "</style>\r\n"
				+ "<table id=\"customers\">" + "<tr>" + "    <th>"+label1+":</th>" + "    <td>" + actual + "</td>" + "</tr>"
				+ "<tr>" + "<th>"+label2+":</th>" + "<td>" + expected + "</td>" + "</tr>" + "<tr>"
				+ "    <th>MESSAGE:</th>" + "    <td>" + msg + "</td>" + "</tr>" + "</table>";

	}

}
