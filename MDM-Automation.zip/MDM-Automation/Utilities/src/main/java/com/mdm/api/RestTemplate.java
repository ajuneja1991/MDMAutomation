package com.mdm.api;

import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import lombok.Getter;
import lombok.Setter;

import static io.restassured.RestAssured.given;

import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;

import org.apache.commons.io.output.ByteArrayOutputStream;

public class RestTemplate {

	@Getter @Setter
	private static String apiRequest;

	
	static final ByteArrayOutputStream baos = new ByteArrayOutputStream();
	static String utf8 = StandardCharsets.UTF_8.name();
	private static PrintStream ps = null;
	private RestTemplate() throws UnsupportedEncodingException{
		ps = new PrintStream(baos, true, utf8);
	}


	public static <T> T get(final RequestSpecification req, final Class<T> repClass) throws UnsupportedEncodingException {
		T resp;
		resp= given().spec(req).filter(new RequestLoggingFilter(ps)).when().log().all().get().then().extract().response().as(repClass);
		RestTemplate.setApiRequest(baos.toString(utf8));
		return resp;
	}

	public static Response get(final RequestSpecification req) throws UnsupportedEncodingException {
		ps = new PrintStream(baos, true, utf8);
		Response resp;
		resp= given().spec(req).filter(new RequestLoggingFilter(ps)).when().log().all().get().then().extract().response();
		RestTemplate.setApiRequest(baos.toString(utf8));
		return resp;
	}

	public <T> T post(final RequestSpecification req, final Class<T> repClass) throws UnsupportedEncodingException {
		T resp;
		resp= given().spec(req).filter(new RequestLoggingFilter(ps)).when().log().all().post().then().extract().response().as(repClass);
		RestTemplate.setApiRequest(baos.toString(utf8));
		return resp;
	}

	public Response post(final RequestSpecification req) throws UnsupportedEncodingException {
		Response resp;
		resp= given().spec(req).filter(new RequestLoggingFilter(ps)).when().log().all().post().then().extract().response();
		RestTemplate.setApiRequest(baos.toString(utf8));
		return resp;	
	}

	public <T> T put(final RequestSpecification req, final Class<T> repClass) throws UnsupportedEncodingException {
		T resp;
		resp= given().spec(req).filter(new RequestLoggingFilter(ps)).when().log().all().put().then().extract().response().as(repClass);
		RestTemplate.setApiRequest(baos.toString(utf8));
		return resp;
	}

	public Response put(final RequestSpecification req) throws UnsupportedEncodingException {
		Response resp;
		resp= given().spec(req).filter(new RequestLoggingFilter(ps)).when().log().all().put().then().extract().response();
		RestTemplate.setApiRequest(baos.toString(utf8));
		return resp;	
	}

}
