package com.mdm.database;

import java.sql.Blob;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import com.mdm.configuration.ConfigurationManager;
import com.mdm.encryption.EncryptionUtil;


/**
 * Database class for DatabaseUtil
 * 
 * @author Vivek Gupta
 */

public class DatabaseUtil {
	private final static String DB_CONNECTION_URL = "db.connection.url";
	private final static String DB_DRIVER_CLASS = "db.driver.class";
	private final static String DB_USER = "db.user";
	private final static String DB_PWD = "db.pwd";
	private final Log logger = LogFactory.getLog(DatabaseUtil.class);


	/**
	 * @param driverCls
	 * @param url
	 * @param user
	 * @param pwd
	 * @return {@link Connection} object
	 * @throws SQLException 
	 * @throws Exception
	 */
	private Connection getConnection() throws SQLException, Exception {
		ConfigurationManager prop = ConfigurationManager.getInstance();
		Connection con=null;
		String driverCls=prop.getProperty(DB_DRIVER_CLASS);
		Class.forName(driverCls);// loads the driver
		String url = prop.getProperty(DB_CONNECTION_URL);
		String user= prop.getProperty(DB_USER);
		String pwd = prop.getProperty(DB_PWD);
		con = DriverManager.getConnection(url, user, new EncryptionUtil().decrypt(pwd));
		System.out.println("Successfully Connected to DB!!");
		return con;
	}


	private DatabaseUtil() {

	}
	private static class LazyHolder
	{
		private static final DatabaseUtil INSTANCE = new DatabaseUtil();
	}

	public static DatabaseUtil dbContext()
	{
		return LazyHolder.INSTANCE;
	}

	/**
	 * 
	 * @param query
	 * @return
	 */
	public Object[][] getData(String query) {
		ArrayList<Object[]> rows = new ArrayList<>();
		Connection con=null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			con = getConnection();
			stmt = con.createStatement();
			rs = stmt.executeQuery(query);

			while (rs.next()) {
				int colsCnt = rs.getMetaData().getColumnCount();
				Object[] cols = new Object[colsCnt];
				for (int indx = 0; indx < colsCnt; indx++) {
					cols[indx] = getValue(rs, indx + 1);
				}
				rows.add(cols);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} 

		return rows.toArray(new Object[][] {});
	}

	/**
	 * 
	 * @param query
	 * @return
	 */
	public Object[][] getDataWithColumn(String query) {
		ArrayList<Object[]> rows = new ArrayList<>();
		Connection con=null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			con = getConnection();
			stmt = con.createStatement();
			rs = stmt.executeQuery(query);

			int col = rs.getMetaData().getColumnCount();
			Object[] header = new Object[col];
			for (int i = 0; i < col; i++ ) {
				String name = rs.getMetaData().getColumnName(i+1);
				header[i] = name;
			}
			rows.add(header);
			while (rs.next()) {
				int colsCnt = rs.getMetaData().getColumnCount();
				Object[] cols = new Object[colsCnt];
				for (int indx = 0; indx < colsCnt; indx++) {
					cols[indx] = getValue(rs, indx + 1);
				}
				rows.add(cols);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} 

		return rows.toArray(new Object[][] {});
	}

	/**
	 * 
	 * @param query
	 * @return
	 */
	public Object[][] getRecordDataAsMap(String query) {
		ArrayList<Object[]> rows = new ArrayList<>();
		Connection con=null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			con = getConnection();
			stmt = con.createStatement();
			rs = stmt.executeQuery(query);

			while (rs.next()) {
				HashMap<String, Object> map = new LinkedHashMap<>();

				int colsCnt = rs.getMetaData().getColumnCount();
				for (int indx = 1; indx <= colsCnt; indx++) {
					map.put(rs.getMetaData().getColumnLabel(indx), getValue(rs, indx));
				}
				rows.add(new Object[] { map });
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return rows.toArray(new Object[][] {});
	}

	/**
	 * Use this method if you have multiple database configuration. Provide prefix of the configuration to be used. 
	 * @see #getConnection(String)
	 * @param connectionPrefix
	 * @param query
	 * @return
	 * @throws Exception 
	 */
	public List<Map<String, Object>> getRecordAsMap(String query) throws Exception {
		System.out.println(query);
		ArrayList<Map<String, Object>> rows = new ArrayList<>();
		Connection con=null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			con = getConnection();
			stmt = con.createStatement();
			rs = stmt.executeQuery(query);

			while (rs.next()) {
				Map<String, Object> map = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);

				int colsCnt = rs.getMetaData().getColumnCount();
				for (int indx = 1; indx <= colsCnt; indx++) {
					map.put(rs.getMetaData().getColumnLabel(indx), getValue(rs,indx));
				}
				rows.add(map);
			}

		} catch (Exception e) {
			throw new Exception(e.getMessage());
		} 
		return rows;
	}

	private Object getValue(ResultSet rs, int colIndex) throws SQLException {
		Object oVal = rs.getObject(colIndex);
		try {
			if(oVal instanceof Blob) {
				oVal = rs.getBytes(colIndex);
			}else if(oVal instanceof Clob) {
				oVal = rs.getString(colIndex);
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return oVal;
	}

	public static final String testquery ="";
	public static void main(String[] args) throws Exception {
		List<Map<String, Object>> x = DatabaseUtil.dbContext().getRecordAsMap(testquery);
		System.out.println(x.get(0));
	}

}
