package com.mdm.hashmap;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

/**
 * This class has methods related to hashmap
 * @author Vivek Gupta
 *
 *
 */
public class HashmapUtils {
	
	private HashmapUtils() {
		throw new IllegalStateException("Hashmap Utils class");
	}

	/**
	 * Method checks if two Maps are equal.
	 * @param <K>
	 * @param <V>
	 * @param first
	 * @param second
	 * @return
	 */
	public static <K,V> boolean areEqual(Map<K, V> first, Map<K, V> second) {
	    if (first.size() != second.size()) {
	        return false;
	    }
	    return first.entrySet().stream()
	      .allMatch(e -> e.getValue().toString().equals(second.get(e.getKey())));
	}
	
	/**
	 * Method returns the mismatched value between two equal Maps
	 * @param <K>
	 * @param <V>
	 * @param actual
	 * @param expected
	 * @return List if mismatch Values and Key
	 * @throws Exception
	 */
	public static <K, V> List<String> mismatchInMap(Map<K, V> actual, Map<K, V> expected) throws Exception{
		List<String> list = new ArrayList<>();
		try {
			for (K y : actual.keySet())
			{
				System.out.println(y);
			    if (!expected.containsKey(y)) {
			        list.add("Expected Map does not contain Key ->"+y+"\r\n");
			    }
			} 
			for (K y : expected.keySet())
			{
			    if (!actual.containsKey(y)) {
			        list.add("Actual Map does not contain Key ->"+y+"\r\n");
			    }
			}
			for (Entry<K, V> k : expected.entrySet())
			{
			    if (!actual.get(k.getKey()).equals(expected.get(k.getKey())) && expected.containsKey(k.getKey())) {
			    	 list.add("Actual => Key ->"+k.getKey().toString()+" Value ->"+actual.get(k.getKey()).toString() +" is not Same as Expected => Key ->"+k.getKey().toString()+ " Value ->"+expected.get(k.getKey()).toString()+"\n");
			    }
			}
		} catch (Exception e) {
			throw new Exception("List Values are ->" +list +"\n Stack Trace-> "+e.getStackTrace());
		}		
		return list;
	}
	
	/**
	 * Method checks for the mis matched value of subset and superset map
	 * @param <K>
	 * @param <V>
	 * @param subset
	 * @param superset
	 * @return
	 * @throws Exception
	 */
	public static <K, V> List<String> mismatchInSubsetNSuperset(Map<K, V> subset, Map<K, V> superset) throws Exception{
		List<String> list = new ArrayList<>();
		try {
			for (K y : subset.keySet())
			{
			    if (!superset.containsKey(y)) {
			        list.add("Superset does not contain Key ->"+y+"\r\n");
			    }
			}
			for (Entry<K, V> k : subset.entrySet())
			{
			    if (!subset.get(k.getKey()).equals(superset.get(k.getKey())) && superset.containsKey(k.getKey())) {
			    	 list.add("Actual => Key ->"+k.getKey().toString()+" Value ->"+subset.get(k.getKey()).toString() +" is not Same as Expected => Key ->"+k.getKey().toString()+ " Value ->"+superset.get(k.getKey()).toString()+"\n");
			    }
			}
		} catch (Exception e) {
			throw new Exception("List Values are ->" +list +"\n Stack Trace-> "+e.getStackTrace());
		}		
		return list;
	}
	
	/**
	 * checks if the Array Values of two maps are equal.
	 * @param first
	 * @param second
	 * @return
	 */
	public static boolean areEqualWithArrayValue(Map<String, String[]> first, Map<String, String[]> second) {
	    if (first.size() != second.size()) {
	        return false;
	    }

	    return first.entrySet().stream()
	      .allMatch(e -> Arrays.equals(e.getValue(), second.get(e.getKey())));
	}
	
	/**
	 * Checks if the keys of two maps are equal.
	 * @param first
	 * @param second
	 * @return
	 */
	public static Map<String, Boolean> areEqualKeyValues(Map<String, String> first, Map<String, String> second) {
	    return first.entrySet().stream()
	      .collect(Collectors.toMap(e -> e.getKey(), 
	        e -> e.getValue().equals(second.get(e.getKey()))));
	}
}
