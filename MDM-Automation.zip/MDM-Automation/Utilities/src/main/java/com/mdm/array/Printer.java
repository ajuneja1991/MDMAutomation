package com.mdm.array;

public interface Printer<T> {
	String print(T obj);
}
