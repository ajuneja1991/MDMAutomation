package com.mdm.array;

public class ArraysUtil {

	
	private ArraysUtil() {
		 throw new IllegalStateException("Arrays Util class");
	}
	
	public static boolean equals(Object[] a, Object[] b) {
	    if(a.length != b.length) return false;
	    outer: for(Object aObject : a) {
	         for(Object bObject : b) {
	              if(aObject.equals(bObject)) continue outer;
	         }
	         return false;
	    }
	    return true;
	}
	
}
