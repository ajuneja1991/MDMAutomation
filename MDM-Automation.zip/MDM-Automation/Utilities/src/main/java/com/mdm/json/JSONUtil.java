package com.mdm.json;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.json.CDL;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

/**
 * This class has all the methods related to JSON manipulation and extraction.
 * 
 * @author Vivek Gupta
 *
 *
 */
public class JSONUtil {
	
	private JSONUtil() {}
	
	@SuppressWarnings("serial")
	public static Map<String, Object> toMap(String jsonString) throws JSONException {
		return new Gson().fromJson(
			    jsonString, new TypeToken<HashMap<String, Object>>() {}.getType()
			);
	}
	
	/**
	 * 
	 * @param str
	 * @return
	 */
	public static boolean isValidJsonString(String str) {
		try {
			new JSONObject(str);
			return true;
		} catch (JSONException e) {
			return false;
		}
	}
	
	/**
	 * 
	 * @param str
	 * @return
	 */
	public static JSONArray getJsonArrayOrNull(String str) {
		try {
			return new JSONArray(str);
		} catch (JSONException e) {
			e.printStackTrace();
			return null;
		}

	}

	/**
	 * 
	 * @param csv
	 * @return
	 */
	public static JSONArray getJsonArrayFromCsvOrNull(String csv){
		try {
			return CDL.rowToJSONArray(new JSONTokener(csv));
		} catch (JSONException e) {
			e.printStackTrace();
			return null;
		}
	}
	

	/**
	 * @param obj
	 * @return
	 */
	static Map<String, Object> toMap(JSONObject obj) {
		Map<String, Object> map = new HashMap<>();
		if (obj != null) {
			Iterator<?> iter = obj.keys();
			while (iter.hasNext()) {
				String key = (String) iter.next();
				try {
					map.put(key, obj.get(key));
				} catch (JSONException e) {

				}
			}
		}
		return map;
	}
	
	public static String toString(Object o) {
		if (String.class.isAssignableFrom(o.getClass()) || o.getClass().isPrimitive()) {
			return String.valueOf(o);
		}
		GsonBuilder builder = new GsonBuilder().setLenient().serializeNulls();
		return builder.create().toJson(o);
	}
	
}
