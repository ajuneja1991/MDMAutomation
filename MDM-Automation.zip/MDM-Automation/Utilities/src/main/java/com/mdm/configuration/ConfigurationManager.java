package com.mdm.configuration;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;
import java.util.Set;



/**
 * This Class is used to perform Read/Write activity in .property file.
 * By default this class take application.properties as the default property file to read 
 * but if required user can set a different property file for Read/Write
 * 
 * Syntax:
 * 
 * 		// Set the Configuration file location 
 * 		ConfigurationManager.configFileName = "name_of_file.properties";
 * 
 * 		// Then get the instance of the call to use it.
 * 		ConfigurationManager.getInstance().getProperty("<Key name for which the value is required.>");
 * 
 * 
 * @author Vivek Gupta
 *
 */
public class ConfigurationManager {

	private final Properties prop = new Properties();
	
	public static String configFileName="./application.properties";
	
	private ConfigurationManager()
	{
		//Private constructor to restrict new instances
		
		try(InputStream in = this.getClass().getClassLoader().getResourceAsStream(configFileName)) {
			prop.load(in);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	

	private static class LazyHolder
	{
		private static final ConfigurationManager INSTANCE = new ConfigurationManager();
	}

	public static ConfigurationManager getInstance()
	{
		return LazyHolder.INSTANCE;
	}

	public String getProperty(String key){
		return prop.getProperty(key);
	}

	public Set<String> getAllPropertyNames(){
		return prop.stringPropertyNames();
	}

	public boolean containsKey(String key){
		return prop.containsKey(key);
	}


	public void setProperty(String key, String value) throws IOException{
		prop.setProperty(key, value);
		ConfigurationManager.getInstance().flush();
	}

	public void flush() throws IOException {
		try (final OutputStream outputstream 
				= new FileOutputStream("application.properties");) {
			prop.store(outputstream,"File Updated");
		}
	}

}
