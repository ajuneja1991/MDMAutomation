package com.mdm.ui;

import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.mdm.configuration.ConfigurationManager;
import com.mdm.datetime.DateTimeUtil;
import com.mdm.directory.DirectoryUtil;

import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.shooting.ShootingStrategies;

public class ScreenshotUtil {
	private ScreenshotUtil() {}
	
	private final static String SCREENSHOT_FOLDER_LOC = ConfigurationManager.getInstance().getProperty("ui.screenshot.folder");

	public static String takeScreenshot(WebDriver driver,String screenshotName) throws IOException {
		  
		  String p = DirectoryUtil.createDirectory(SCREENSHOT_FOLDER_LOC)+"/"+screenshotName+"_"+ DateTimeUtil.getCurrentDateTime() + ".png";
	        try {
	        	File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	            FileUtils.copyFile(screenshot, new File(p));
	        } catch (Exception e) {
	        	throw new IOException(e.getMessage());
	        }
	        return p;
	}
	
	public static String takeElementScreenshot(WebElement element, String screenshotName) throws IOException {
		 String p = DirectoryUtil.createDirectory(SCREENSHOT_FOLDER_LOC)+"/"+screenshotName+"_"+ DateTimeUtil.getCurrentDateTime() + ".png";
		try {
				File screenshot = element.getScreenshotAs(OutputType.FILE);
	            FileUtils.copyFile(screenshot, new File(p));
	        } catch (IOException e) {
	        	throw new IOException(e.getMessage());
	        }
		return p;
	}
	
	public static String takeFullPageScreenshot(WebDriver driver, String screenshotName) throws IOException {
		String p = DirectoryUtil.createDirectory(SCREENSHOT_FOLDER_LOC)+"/"+screenshotName+"_"+ DateTimeUtil.getCurrentDateTime() + ".png";
		Screenshot screenshot= new AShot().shootingStrategy(ShootingStrategies.viewportPasting(1000)).takeScreenshot(driver);
		ImageIO.write(screenshot.getImage(), "PNG", new File(p));
		System.out.println(new File(p).getCanonicalPath());
		return new File(p).getCanonicalPath();
	}

}
