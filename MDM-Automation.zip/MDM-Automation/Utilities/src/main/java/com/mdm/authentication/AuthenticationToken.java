package com.mdm.authentication;

import org.apache.commons.codec.binary.Base64;

import com.mdm.configuration.ConfigurationManager;
import com.mdm.encryption.EncryptionUtil;


/**
 * This class is used to get the API Authentication token for MDM API
 * 
 * @author Vivek Gupta
 *
 */
public class AuthenticationToken {

	private ConfigurationManager prop;

	private AuthenticationToken() {
		prop = ConfigurationManager.getInstance();
	}

	private static class LazyHolder
	{
		private static final AuthenticationToken INSTANCE = new AuthenticationToken();
	}

	public static AuthenticationToken getInstance()
	{
		return LazyHolder.INSTANCE;
	}

	
	/**
	 * This method is used to generate the API token for Authentication 
	 * @implSpec : userName, password and header Authorization value has been picked from the property file, by default currently application.property is used.
	 * 	
	 * @return : API authorization token string 
	 * @throws Exception 
	 * @throws  
	 */
	public String generateMDMAuthToken() throws Exception {

		String authenticationToken = prop.getProperty("api.token.headerAuthorizationVal");			
		StringBuilder username = new StringBuilder(prop.getProperty("api.token.userName"));
		StringBuilder password = new StringBuilder(prop.getProperty("api.token.password"));
		StringBuilder usernameColon = username.append(":");
		StringBuilder usernameColonPassword = usernameColon.append(new EncryptionUtil().decrypt(password.toString()));
		String usernameColonPasswordString = usernameColonPassword.toString();
		byte[] encodedBytes = Base64.encodeBase64(usernameColonPasswordString.getBytes());
		authenticationToken += new String(encodedBytes);

		return authenticationToken;
	}

	public static void main(String[] args) throws Exception {
		System.out.println(AuthenticationToken.getInstance().generateMDMAuthToken());
	}

}
