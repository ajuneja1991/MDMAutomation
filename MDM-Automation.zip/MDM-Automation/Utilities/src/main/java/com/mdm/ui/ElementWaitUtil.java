package com.mdm.ui;

import java.time.Duration;
import java.util.NoSuchElementException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.mdm.configuration.ConfigurationManager;

public class ElementWaitUtil {

	private ElementWaitUtil() {}

	private static WebDriverWait waitExplicit = null;
	private static FluentWait<WebDriver> waitFluent = null;

	public static FluentWait<WebDriver> getFluentWait(WebDriver driver) {
		if(ElementWaitUtil.waitFluent == null) {
			ElementWaitUtil.waitFluent = new FluentWait<WebDriver>(driver)
					.withTimeout(Duration.ofSeconds(120))
					.pollingEvery(Duration.ofMillis(500))
					.ignoring(NoSuchElementException.class);
		}
		return ElementWaitUtil.waitFluent;
	}

	public static WebDriverWait getExplicitWait(WebDriver driver) {
		if(ElementWaitUtil.waitExplicit == null) {
			ElementWaitUtil.waitExplicit = new WebDriverWait(driver,Duration.ofSeconds(Integer.parseInt(ConfigurationManager.getInstance().getProperty("ui.max.timeout"))));
		}
		return ElementWaitUtil.waitExplicit;
	}
	
	public static void waitForTextToDisappear(WebDriver driver, WebElement el, String text) {
		ElementWaitUtil.getFluentWait(driver).until(ExpectedConditions.not(ExpectedConditions.textToBePresentInElement(el, text)));		
	}
	
	public static void waitForElementToDisappear(WebDriver driver, WebElement el) {
		ElementWaitUtil.getFluentWait(driver).until(ExpectedConditions.invisibilityOf(el));		
	}


	public static void waitForLoaderToDisappear(WebDriver driver, WebElement el) {
		ElementWaitUtil.getExplicitWait(driver);
		ElementWaitUtil.waitExplicit.until(ExpectedConditions.invisibilityOf(el));
	}

	public static void switchToFrameBasisOfId(WebDriver driver, String ID) {
		ElementWaitUtil.getExplicitWait(driver);
		ElementWaitUtil.waitExplicit.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.id(ID)));
	}

	public static void switchToFrameBasisOfName(WebDriver driver, String frameName) {
		ElementWaitUtil.getExplicitWait(driver);
		ElementWaitUtil.waitExplicit.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(frameName));
	}

	public static void switchToFrameBasisOfIndex(WebDriver driver, int frameIndex) {
		ElementWaitUtil.getExplicitWait(driver);
		ElementWaitUtil.waitExplicit.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(frameIndex));
	}



	public static void waitForElementToBeVisible(WebDriver driver, String xpathExpression) {
		ElementWaitUtil.getExplicitWait(driver);
		ElementWaitUtil.waitExplicit.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpathExpression)));
	}

	public static void waitForElementToBeVisible(WebDriver driver, WebElement el) {
		ElementWaitUtil.getExplicitWait(driver);
		ElementWaitUtil.waitExplicit.until(ExpectedConditions.visibilityOf(el));
	}
	
	public static void waitForElementToBePresent(WebDriver driver, WebElement el, By by) {
		ElementWaitUtil.getExplicitWait(driver);
		ElementWaitUtil.waitExplicit.until(ExpectedConditions.presenceOfNestedElementLocatedBy(el,by));
	}

	public static void waitForElementToBePresent(WebDriver driver, By by) {
		ElementWaitUtil.getExplicitWait(driver);
		ElementWaitUtil.waitExplicit.until(ExpectedConditions.presenceOfElementLocated(by));
	}
	
	public static void waitForElementToBeClickable(WebDriver driver, String xpathExpression) {
		ElementWaitUtil.getExplicitWait(driver);
		ElementWaitUtil.waitExplicit.until(ExpectedConditions.elementToBeClickable(By.xpath(xpathExpression)));
	}

	public static void waitForElementToBeClickable(WebDriver driver, WebElement el) {
		ElementWaitUtil.getExplicitWait(driver);
		ElementWaitUtil.waitExplicit.until(ExpectedConditions.elementToBeClickable(el));
	}

	public static void waitForElementToBeEnabled(WebDriver driver, WebElement inputEle) {
		ElementWaitUtil.getExplicitWait(driver);
		ElementWaitUtil.waitExplicit.until(ExpectedConditions.elementToBeClickable(inputEle));
	}

	public static void waitForElementToBeSelected(WebDriver driver, String xpathExpression) {
		ElementWaitUtil.getExplicitWait(driver);
		ElementWaitUtil.waitExplicit.until(ExpectedConditions.elementToBeSelected(By.xpath(xpathExpression)));
	}

	public static void waitForDropDownLoadingBarToDisappear(WebDriver driver) {
		ElementWaitUtil.getExplicitWait(driver);
		ElementWaitUtil.waitExplicit.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(@id,'ebx_ISS_Item_')]")));
	}

	public static void waitForDropDownElementToBeClickable(WebDriver driver) {
		ElementWaitUtil.getExplicitWait(driver);
		ElementWaitUtil.waitExplicit.until(ExpectedConditions.numberOfElementsToBeMoreThan(By.className("ebx_ISS_Item_WithPreview"), 0));
	}

	public static void waitForPageLoad(WebDriver driver) throws TimeoutException {
		try {
			WebDriverWait driverWait = new WebDriverWait(driver, Duration.ofSeconds(Integer.parseInt(ConfigurationManager.getInstance().getProperty("ui.max.timeout"))));	        
			  ExpectedCondition<Boolean> expectation= new ExpectedCondition<Boolean>() {
		            public Boolean apply(WebDriver driverjs) {
		                JavascriptExecutor js = (JavascriptExecutor) driverjs;
		                return js.executeScript("return((window.jQuery != null) && (jQuery.active === 0))").equals("true");
		            }
		        };        
			driverWait.until(expectation);
		}catch (WebDriverException e) {
			throw new WebDriverException(e.getMessage());
		}
	}
	
	public static void waitForReady(WebDriver driver) {
		ElementWaitUtil.getExplicitWait(driver);
		ElementWaitUtil.waitExplicit.until(EXPECT_DOC_READY_STATE);
	}
	public static void waitForPOMRefresh(WebElement element) {

		ElementWaitUtil.waitExplicit.until(ExpectedConditions.refreshed(ExpectedConditions.stalenessOf(element)));
	}
	
	public static final ExpectedCondition<Boolean> EXPECT_DOC_READY_STATE = new ExpectedCondition<Boolean>() {
	    @Override
	    public Boolean apply(WebDriver driver) {
	        String script = "if (typeof window != 'undefined' && window.document) { return window.document.readyState; } else { return 'notready'; }";
	        Boolean result;
	        try {
	            result = ((JavascriptExecutor) driver).executeScript(script).equals("complete");
	        } catch (Exception ex) {
	            result = Boolean.FALSE;
	        }
	        return result;
	    }
	};

}
