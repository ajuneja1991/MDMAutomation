package com.mdm.ui;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class JSUtil {
	
	static WebDriver driver;
	private JSUtil() {
	}

	private static class LazyHolder
	{
		private static final JSUtil INSTANCE = new JSUtil();
	}

	public static JSUtil getInstance(WebDriver driver)
	{
		JSUtil.driver = driver;
		return LazyHolder.INSTANCE;
	}

	
	public void scrollElementIntoView(WebElement el) {
		JavascriptExecutor jse = ((JavascriptExecutor) driver);
		jse.executeScript("arguments[0].scrollIntoView(true);", el);
	}
	
}
