package com.mdm.excel;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;
import com.mdm.array.PrettyPrintArray;
import com.mdm.configuration.ConfigurationManager;

import lombok.Getter;
import lombok.NonNull;
import lombok.Setter;

/**
 * This class has methods to perform action on excel using Apache POI and querying using SQL.
 * 
 * @author Vivek Gupta
 *
 */

public class ExcelUtil {

	private static final Log logger = LogFactory.getLog(ExcelUtil.class);
	private String path;

	@Getter
	@Setter
	private String startRow = "1";
	@Getter
	@Setter
	private String startColumn = "1";

	private final String defaultExcelPath = ConfigurationManager.getInstance().getProperty("testdata.excel.path");

	public ExcelUtil(String...excelPath) {
		this.path = excelPath.length>0?excelPath[0]:defaultExcelPath;
	}

	/**
	 * 
	 * @param columName - the column for which you want to read the value from Excel sheet.
	 * @return Returns List of values under specified column name
	 * @throws FilloException
	 */
	public List<String> readExcelByQuery(@NonNull String columName, @NonNull String query) throws FilloException {

		System.setProperty("ROW", getStartRow());// Table start row
		System.setProperty("COLUMN", getStartColumn());// Table start column
		Recordset recordset = null;
		Connection connection = null;
		try {
			Fillo fillo = new Fillo();
			connection = fillo.getConnection(path);
			recordset = connection.executeQuery(query);

			List<String> result = new ArrayList<>();
			while (recordset.next()) {
				result.add(recordset.getField(columName));
			}
			recordset.close();
			connection.close();
			return result;
		} catch (NullPointerException ex) {
			logger.error(ex.getMessage());
			throw new NullPointerException("NULL value is coming for-> " + ex.getMessage());
		}

	}

	/**
	 * 
	 * @param query - the query for reading the data.
	 * @return Returns List of values under specified column name
	 * @throws FilloException
	 */
	public Map<String,List<String>> readExcelByQuery(@NonNull String query) throws FilloException {

		System.setProperty("ROW", getStartRow());// Table start row
		System.setProperty("COLUMN", getStartColumn());// Table start column
		Recordset rs = null;
		Connection connection = null;
		try {
			Fillo fillo = new Fillo();
			connection = fillo.getConnection(path);
			rs = connection.executeQuery(query);

			List<String> column = rs.getFieldNames();
			Map<String, List<String>> map = new HashMap<>(column.size());
			for (int i = 0; i < column.size(); ++i) {
				map.put(column.get(i), new ArrayList<>());
			}
			while (rs.next()) {
				for (int i = 0; i < column.size(); ++i) {
					map.get(column.get(i)).add(rs.getField(column.get(i)));
				}
			}
			rs.close();
			connection.close();
			return map;
		} catch (NullPointerException ex) {
			logger.error(ex.getMessage());
			throw new NullPointerException("NULL value is coming for-> " + ex.getMessage());
		}

	}

	public Object[][] readExcelData(String query) throws FilloException {

		System.setProperty("ROW", getStartRow());// Table start row
		System.setProperty("COLUMN", getStartColumn());// Table start column
		Connection connection = null;

		Fillo fillo = new Fillo();
		connection = fillo.getConnection(path);
		Recordset recordset = connection.executeQuery(query);
		Map<String, String> table;		  
		Object[][] data = new Object[recordset.getCount()][1];		  
		int rowIndex = 0;

		while (recordset.next()) {
			table = new HashMap<>();
			for (String strColumn : recordset.getFieldNames()) {
				table.put(strColumn, recordset.getField(strColumn));
				// putting table header (column name) and corresponding data in hash map as key value pair
			}
			data[rowIndex][0] = table; // putting hash map into Object array
			rowIndex++;
		}

		recordset.close();
		connection.close();
		return data;

	}

	/**
	 * Method to update values to excel file using the SQL query, 
	 * this can perform both insert and update on the excel just we need to pass the query accordingly.
	 * @throws FilloException
	 */
	public void updateExcelByQuery( @NonNull String query) throws FilloException {
		Fillo fillo = new Fillo();
		Connection connection = fillo.getConnection(path);
		connection.executeUpdate(query);
		connection.close();
	}

	public static void main(String[] args) throws FilloException {
		String ExtentReportFolder = System.getProperty("user.dir") + "\\src\\test\\resources\\Data.xlsx";
		// String query = "Select * from CreateLead";
		//String query = "Update CreateLead Set projectDescription='Lead' where projectDescription='US'";
		//ExcelUtil obj = new ExcelUtil(ExtentReportFolder);
		//	obj.updateExcelByQuery(query);
		String query1 = "Select * from CreateLead";
		ExcelUtil obj1 = new ExcelUtil(ExtentReportFolder);
		System.out.println( PrettyPrintArray.print(obj1.readExcelData(query1)));
		//obj.setStartColumn(null);
	}

}
