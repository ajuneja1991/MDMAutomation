package com.mdm.reporting;

import java.io.FileNotFoundException;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.mdm.configuration.ConfigurationManager;
import com.mdm.datetime.DateTimeUtil;
import com.mdm.directory.DirectoryUtil;


/**
 * <p>
 * Singleton Class for ExtentReports.
 * </p>
 * <p>
 * ExtentReports extent instance created here. That instance can be reachable by
 * getReporter() method.
 * </p>
 * 
 * @author Vivek Gupta
 *
 */

public class ExtentManager {
	private static ExtentReports extent;
	private static ExtentHtmlReporter htmlReporter;
	public static ExtentTest extentTest;
	public static ExtentTest parentTest;
	public static ExtentTest childTest;
	private final static String ExtentReportFolder = ConfigurationManager.getInstance().getProperty("ui.current.report");//System.getProperty("user.dir") + "\\ExtentReports";

	/**
	 * Constructor is made private to block creation of multiple objects of this
	 * class
	 */

	private ExtentManager() {

	}

	/**
	 * <p>
	 * This method will ensure only one object of ExtentReports exists at any point
	 * of time.
	 * </p>
	 * <p>
	 * In this method we would create ExtentHtmlReporter object to set various
	 * properties for our final HTML report. We will then create ExtentReports and
	 * attach the reporter object with it. Also, we will set System Info using
	 * ExtentReports object.
	 * </p>
	 * 
	 * @return ExtentReports object
	 * @throws FileNotFoundException
	 */
	public synchronized static ExtentReports getReporter() throws FileNotFoundException {
		if (extent == null) {
			// Set HTML reporting file location and properties
			String reportPath = DirectoryUtil.createDirectory(ExtentReportFolder) + "\\ExtentReportResults_"
					+ DateTimeUtil.getCurrentDateTime() + ".html";
			htmlReporter = new ExtentHtmlReporter(reportPath);
			htmlReporter.config().setReportName("MDM UI Automation Tests Report");
			htmlReporter.config().setDocumentTitle("Test Automation Report");
			htmlReporter.config().setTheme(Theme.DARK);

			// Attach HTML reporter with ExtentReports and set system information
			extent = new ExtentReports();
			extent.attachReporter(htmlReporter);
			extent.setSystemInfo("Author", "Vivek Gupta");
			extent.setSystemInfo("Project", "MDM");
			extent.setSystemInfo("Tests", "UI");
			extent.setSystemInfo("Test Library", "Selenium");
			extent.setSystemInfo("Language", "Java");
		}
		return extent;
	}

	public static void createTestClassNode(String testClassName) {
		parentTest = extent.createTest(testClassName);
	}

	public static void createTestNode(String testClassName, String testCaseName, String desc) {
		childTest = parentTest.createNode(testCaseName, desc);
		childTest.assignCategory(testClassName);
	}

	public static void writeTest() {
		extent.flush();
	}

	public static ExtentTest logger() {
		return childTest;
	}

}
