package com.mdm.directory;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.commons.io.FileUtils;


/**
 * This Class has method related to directory/folder/sub folder creation, movement and deletion
 * 
 * 
 * @author Vivek Gupta
 *
 */
public class DirectoryUtil {
	
	private DirectoryUtil() {
		throw new IllegalStateException("DirectoryUtil class");
	}

	public static String createDirectory(String path) throws FileNotFoundException {
		//File theDir = new File(System.getProperty("user.dir"),path);
		File theDir = new File(path);
		if (!theDir.exists()) {
			theDir.mkdirs();
		}
		if (theDir.exists()) {
			return path;
		} else {
			throw new FileNotFoundException("Folder not created at path: " + path);
		}

	}

	public static void moveFile(String srcDir, String destDir) {
		try {
			// source & destination directories
			File src = new File(srcDir);
			File dest = new File(destDir);

			// check if the source directory exist if not create
			createDirectory(destDir);

			FileUtils.copyDirectory(src, dest);
			FileUtils.cleanDirectory(src);

		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}

}
