package com.mdm.string;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Locale;


/**
 * This class has method for formatting numbers, currency, decimals, padding 0 and returning String for it.
 * 
 * @author Vivek Gupta
 *
 *
 */
public class StringFormator {
	
	private StringFormator() {
	    throw new IllegalStateException("StringFormator class");
	  }

	
	/**
	 * method formats number in ###,###,### format
	 * @param value
	 * @return formated value
	 * 
	 * E.g. : input -> 123456789
			  output-> 123,456,789
	 */
	public static String formatNbr(double value) {
	    DecimalFormat df = new DecimalFormat("###,###,###");
	    return df.format(value);
	}
	
	/**
	 * method formats number in ######### format
	 * @param value
	 * @return formated value
	 * 
	 * E.g. : input -> 123,456,789
			  output-> 123456789
	 */
	public static String formatNbrToString(String value) {
		value = value.replaceAll("[^a-zA-Z0-9]","");
	    return value;
	}
	
	/**
	 * method format the number to 2 decimal places
	 * @param value
	 * @return
	 *  input-> 12
	 *  output-> 12.00
	 *   
	 */
	public static String withTwoDecimalPlaces(double value) {
	    DecimalFormat df = new DecimalFormat("#.00");
	    return df.format(value);
	}
	
	/**
	 * Method formats the number and adds % to it 
	 * @param value
	 * @param locale
	 * @return
	 * 
	 * e.g.
	 * double value = 25f / 100f;
	 * assertThat(forPercentages(value, new Locale("en", "US"))).isEqualTo("25%");
	 */
	public static String forPercentages(double value, Locale locale) {
	    NumberFormat nf = NumberFormat.getPercentInstance(locale);
	    return nf.format(value);
	}
	
	
	/**
	 * Method adds currency symbol as per the locale
	 * @param value
	 * @param locale
	 * @return
	 * e.g.
	 *  double value = 23_500;
	 *	assertThat(currencyWithChosenLocalisation(value, new Locale("en", "US"))).isEqualTo("$23,500.00");
	 */
	public static String currencyWithChosenLocalisation(double value, Locale locale) {
	    NumberFormat nf = NumberFormat.getCurrencyInstance(locale);
	    return nf.format(value);
	}
	
	/**
	 * 
	 * @param value
	 * @param paddingLength
	 * @return
	 * int value = 1;
	 * assertThat(byPaddingOutZeros(value, 3)).isEqualTo("001");
	 */
	public static String byPaddingZeros(int value, int paddingLength) {
	    return String.format("%0" + paddingLength + "d", value);
	}
}
